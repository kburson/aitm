"""Retain canonical provider history, native job checks and exact artifact bytes."""

import argparse
import json
import subprocess
from hashlib import sha256
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "records"
REPO = (OUT / "repository").read_text().strip()


def read(path):
    return json.loads(path.read_bytes())


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def api(route):
    return subprocess.check_output(["gh", "api", f"repos/{REPO}/{route}"])


def capture(out, route):
    data = json.loads(api(route))
    write(out, data)
    return data


def record(run):
    run_id = run["id"]
    route = f"actions/runs/{run_id}"
    out = OUT / "hosted" / str(run_id)
    out.mkdir(parents=True, exist_ok=True)
    record = capture(out / "run.json", route)
    assert (record["head_sha"], record["head_branch"], record["run_attempt"]) == (
        run["head_sha"], run["head_branch"], run["run_attempt"]
    )
    suite = capture(out / "suite.json", f"check-suites/{run['check_suite_id']}")
    assert suite["app"]["id"] == 15368 and suite["head_sha"] == run["head_sha"]
    assert run["status"] == record["status"] == "completed"
    entries = capture(out / "artifacts.json", f"{route}/artifacts?per_page=100")["artifacts"]
    for entry in entries:
        assert entry["workflow_run"]["id"] == run_id and entry["workflow_run"]["head_sha"] == run["head_sha"]
        data = api(f"actions/artifacts/{entry['id']}/zip")
        assert len(data) == entry["size_in_bytes"] and "sha256:" + sha256(data).hexdigest() == entry["digest"]
        name = entry["name"]
        assert name.startswith("aitm-ci-") and "/" not in name
        (out / f"{name}.zip").write_bytes(data)
    for attempt in range(1, run["run_attempt"] + 1):
        one = out / f"attempt-{attempt}"
        one.mkdir(exist_ok=True)
        target = f"{route}/attempts/{attempt}"
        native = capture(one / "attempt.json", target)
        assert native["run_attempt"] == attempt and native["head_sha"] == run["head_sha"]
        jobs = capture(one / "jobs.json", f"{target}/jobs?per_page=100")["jobs"]
        for job in jobs:
            check = capture(one / f"check-{job['id']}.json", f"check-runs/{job['id']}")
            assert check["name"] == job["name"] and check["app"]["id"] == 15368
            assert check["head_sha"] == run["head_sha"] and check["check_suite"]["id"] == suite["id"]
        log_args = ["gh", "run", "view", str(run_id), "-R", REPO, "--attempt", str(attempt), "--log"]
        with (one / "actions.log").open("wb") as log:
            subprocess.run(log_args, stdout=log, stderr=subprocess.STDOUT, check=True)


def main():
    assert REPO == "kburson/aitm-feedback-339"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="append", type=int)
    args = parser.parse_args()
    workflow = read(OUT / "lab-workflow.json")
    rows = capture(OUT / "canonical-runs.json", f"actions/workflows/{workflow['id']}/runs?event=pull_request&per_page=100")
    branches = {"probe/control", "probe/treatment"}
    assert rows["total_count"] == len(rows["workflow_runs"])
    for row in rows["workflow_runs"]:
        assert row["head_branch"] in branches and row["event"] == "pull_request"
        if args.run is None or row["id"] in args.run:
            record(row)
    if args.run is None:
        for number, arm in ((1, "control"), (2, "treatment")):
            arm_records = OUT / arm
            path = arm_records / (arm_records / "authorized-pass-path").read_text().strip()
            verifier = read(path / "trusted-verifier.json")
            capture(path / "synthetic.json", f"git/commits/{verifier['tested']}")
            capture(OUT / f"pr-{number}-commits.json", f"pulls/{number}/commits")
            capture(OUT / f"pr-{number}-timeline.json", f"issues/{number}/timeline?per_page=100")
            pull = capture(OUT / f"pr-{number}-final.json", f"pulls/{number}")
            capture(OUT / f"pr-{number}-final-synthetic.json", f"git/commits/{pull['merge_commit_sha']}")


if __name__ == "__main__":
    main()
