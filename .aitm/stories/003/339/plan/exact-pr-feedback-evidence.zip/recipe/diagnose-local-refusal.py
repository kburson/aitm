"""Identify current classified and unclassified IDs through stock TIA collection."""

import collections
import json
import sys
import tempfile
from pathlib import Path

from tools.ci.tia import local

base = sys.argv[1]
repo, request = local._request(base)
_, candidate = local.resolve(repo, request)
with tempfile.TemporaryDirectory(prefix="aitm-339-collect-", dir=repo.parent.resolve()) as private:
    runtime = local._prepare(candidate, Path(private) / "observation")
    policy = local.SuitePolicy(
        (runtime.root / local._SUITES).read_bytes(),
        (runtime.root / local._POLICY).read_bytes(),
        "full",
    )
    rules = local.t02._policy(policy)
    results = {}
    for profile, _scope in sorted(rules.workloads["full"]["required_pairs"]):
        lane = rules.profiles[profile]
        observed = runtime.pytest(profile, tuple(lane["targets"]), collect=True).receipt()
        assert all(
            node.partition("::")[0].encode() in runtime.source.entries
            for node in observed["collected"]
        ), "private collection path provenance not canonical"
        unclassified = collections.Counter(
            source for node in observed["collected"]
            if (source := node.partition("::")[0]) not in rules.modules
        )
        results[profile] = {
            "collected_count": len(observed["collected"]),
            "unclassified_modules_and_counts": dict(sorted(unclassified.items())),
            "collected": observed["collected"],
        }
    print(json.dumps({"base": base, "candidate_snapshot": candidate.digest, "observations": results}, indent=2))
