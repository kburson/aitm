#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
cd "$root"
export PYTHONDONTWRITEBYTECODE=1
python3 recipe/capture-hosted.py
python3 recipe/capture-parity.py
python3 recipe/replay.py > qualification-summary.json
python3 recipe/render-report.py > 2026-11-16-339-exact-pr-feedback-results.md
python3 recipe/pack.py
shasum -a 256 \
  2026-11-16-339-exact-pr-feedback-plan.md \
  2026-11-16-339-preflight-recovery.md \
  2026-11-16-339-exact-pr-feedback-results.md \
  exact-pr-feedback-evidence.zip \
  qualification-summary.json \
  reproduction.md > SHA256SUMS
