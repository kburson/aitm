"""Exercise one arm without changing the canonical GitHub PR gate."""

import argparse
import json
import os
import subprocess
import sys
import time
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = "packages/aitm-usage/tests/fixtures/grok/headless.json"
PROMPT = "20000000-0000-4000-8000-000000000001"
NODE = "test_headless_projection_is_only_corroboration"
ASSERTION = "assert len(baseline.observations) == 2 and not baseline.diagnostics"
CONTEXTS = {"python-base", "python", "quality", "file-checks", "collect-evidence", "aitm-ci"}


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def instant():
    return datetime.now(UTC).isoformat()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


class Arm:
    def __init__(self, name):
        self.name = name
        self.root = ROOT / name
        self.base = (ROOT / "records/production-base").read_text().strip()
        self.repo = (ROOT / "records/repository").read_text().strip()
        need(self.repo != "kburson/aitm", "lab repository required")
        self.workflow = json.loads((ROOT / "records/lab-workflow.json").read_text())
        self.out = ROOT / "records" / name
        self.out.mkdir(exist_ok=True)
        self.pr = None

    def event(self, event, **details):
        row = {"utc": instant(), "event": event, **details}
        with (self.out / "events.jsonl").open("a") as log:
            log.write(json.dumps(row, sort_keys=True) + "\n")
        print(self.name, row, flush=True)

    def process(self, command, out, *, expected=0, cwd=None):
        destination = self.out / out
        with destination.open("wb") as stream, destination.with_suffix(
            destination.suffix + ".stderr"
        ).open("wb") as err:
            result = subprocess.run(
                command,
                cwd=cwd or self.root,
                stdout=stream,
                stderr=err,
                check=False,
                env=os.environ | {"PYTHONDONTWRITEBYTECODE": "1"},
            )
        need(
            result.returncode == expected,
            f"{command[0]} exit {result.returncode}, expected {expected}; see {destination}",
        )
        return destination

    def git(self, *args):
        return subprocess.check_output(["git", "-C", str(self.root), *args], text=True).strip()

    def api(self, path):
        return json.loads(
            subprocess.check_output(["gh", "api", f"repos/{self.repo}/{path}"])
        )

    def candidate(self, phase, count):
        rows = json.loads(self.git("show", f"{self.base}:{FIXTURE}"))
        need(len(rows) == 2, "fixture not the predeclared two-row source")
        target = next(row for row in rows if row["requestId"] == PROMPT)
        need(target["usage"]["input_tokens"] == 12789, "unexpected source fixture value")
        target["usage"]["input_tokens"] = count
        rows.reverse()
        path = self.root / FIXTURE
        path.write_text(json.dumps(rows, indent=2) + "\n")
        self.git("add", "--", FIXTURE)
        self.git("commit", "-qm", f"#339 {self.name}: {phase} Grok evidence fixture")
        identity = {
            "base": self.base,
            "head": self.git("rev-parse", "HEAD"),
            "tree": self.git("rev-parse", "HEAD^{tree}"),
            "fixture_blob": self.git("rev-parse", f"HEAD:{FIXTURE}"),
            "changes": self.git("diff", "--name-only", self.base, "HEAD").splitlines(),
        }
        need(identity["changes"] == [FIXTURE], "candidate changed more than fixture")
        write_json(self.out / f"{phase}-candidate.json", identity)
        (self.out / f"{phase}-candidate.diff").write_text(
            self.git("diff", "--binary", self.base, "HEAD") + "\n"
        )
        self.event("candidate_committed", phase=phase, **identity)
        return identity

    def preflight(self, phase, identity, *, expected):
        self.event("local_tia_started", phase=phase, **identity)
        destination = self.process(
            [sys.executable, "-m", "tools.ci.tia.local", "--base", self.base, "--run"],
            f"{phase}-local-tia.json",
            expected=expected,
        )
        evidence = json.loads(destination.read_text())
        result = evidence["result"]
        need(result["exit_code"] == expected, "advisory evidence exit mismatch")
        outcomes = [row for p in result["profiles"] for row in p["outcomes"]]
        relevant = [row for row in outcomes if row["nodeid"].endswith("::" + NODE)]
        target_status = "failed" if expected else "passed"
        need(result["status"] == target_status, "unexpected advisory result")
        need(len(relevant) == 1 and relevant[0]["outcome"] == target_status, "local behavior not observed")
        if expected:
            failures = [row for row in outcomes if row["outcome"] == "failed"]
            need(failures == relevant, f"unexpected local failures: {failures}")
            need(
                any(ASSERTION in p.get("diagnostic", "") for p in result["profiles"]),
                "local diagnostic misses the expected behavioral assertion",
            )
        self.event(
            "local_tia_finished",
            phase=phase,
            mode=evidence["plan"]["mode"],
            executed=result["executed"],
            result=result["status"],
            obligation=relevant[0]["nodeid"],
        )

    def publish(self, phase, identity):
        self.event("provider_publish_started", phase=phase, head=identity["head"])
        branch = self.git("branch", "--show-current")
        self.process(["git", "push", "-u", "origin", branch], f"{phase}-push.txt")
        if self.pr is None:
            destination = self.process(
                [
                    "gh", "pr", "create", "-R", self.repo, "--base", "trunk", "--head", branch,
                    "--title", f"#339 exact PR feedback {self.name} arm",
                    "--body", "Disposable experiment with canonical full #103 and no production changes.",
                ],
                "pr-url.txt",
            )
            self.pr = int(destination.read_text().strip().rsplit("/", 1)[1])
        self.event("provider_publish_returned", phase=phase, pr=self.pr, head=identity["head"])
        for observation in range(10):
            pull = self.api(f"pulls/{self.pr}")
            write_json(self.out / f"{phase}-publish-readback-{observation}.json", pull)
            if pull["head"]["sha"] == identity["head"]:
                break
            time.sleep(2)
        need(pull["head"]["sha"] == identity["head"], "published head mismatch")
        need(pull["base"]["sha"] == self.base, "published base changed")
        write_json(self.out / f"{phase}-post-publish-pr.json", pull)

    def wait_for_terminal(self, phase, head):
        branch = quote(self.git("branch", "--show-current"), safe="")
        url = f"actions/workflows/{self.workflow['id']}/runs?event=pull_request&branch={branch}&per_page=100"
        deadline = time.monotonic() + 1200
        previously_observed = None
        while time.monotonic() < deadline:
            rows = self.api(url)["workflow_runs"]
            matched = [row for row in rows if row["head_sha"] == head]
            if matched:
                run = max(matched, key=lambda row: (row["created_at"], row["id"]))
                observed = (run["id"], run["run_attempt"], run["status"])
                if observed != previously_observed:
                    self.event(
                        "provider_run_observed",
                        phase=phase,
                        run=run["id"],
                        attempt=run["run_attempt"],
                        status=run["status"],
                        conclusion=run["conclusion"],
                        registration=run["created_at"],
                    )
                    previously_observed = observed
                if run["status"] == "completed":
                    write_json(self.out / f"{phase}-run-list.json", rows)
                    return run
            time.sleep(5)
        raise RuntimeError(f"no terminal run observed for {phase} {head}")

    def verify(self, phase, run, identity, *, expected):
        run_id, attempt = run["id"], run["run_attempt"]
        route = f"actions/runs/{run_id}/attempts/{attempt}"
        prefix = self.out / f"{phase}-{run_id}-a{attempt}"
        prefix.mkdir()
        pull = self.api(f"pulls/{self.pr}")
        tested = self.api(f"git/commits/{pull['merge_commit_sha']}")
        need(
            [p["sha"] for p in tested["parents"]] == [self.base, identity["head"]]
            and tested["tree"]["sha"] == identity["tree"],
            "current GitHub merge has a different base, head or tree",
        )
        write_json(prefix / "pull.json", pull)
        write_json(prefix / "tested.json", tested)
        verifier = ROOT / "lab/tools/ci/verify_pr.py"
        receipt_path = prefix / "trusted-verifier.json"
        relative = prefix.relative_to(self.out)
        self.event("trusted_verification_started", phase=phase, run=run_id, attempt=attempt)
        verifier_args = [
            sys.executable, str(verifier), "--repo", self.repo, "--pr", str(self.pr),
            "--target", "trunk", "--output", str(receipt_path),
        ]
        with (prefix / "trusted-verifier.log").open("wb") as log:
            result = subprocess.run(
                verifier_args, cwd=ROOT / "lab", stdout=log, stderr=subprocess.STDOUT, check=False
            )
        receipt = json.loads(receipt_path.read_text())
        self.event("trusted_verification_finished", phase=phase, run=run_id, attempt=attempt, **{
            key: receipt[key] for key in ("status", "verified_at")
        })
        write_json(prefix / "run.json", self.api(f"actions/runs/{run_id}"))
        write_json(prefix / "attempt.json", self.api(route))
        jobs = self.api(f"{route}/jobs")["jobs"]
        write_json(prefix / "jobs.json", jobs)
        suite = self.api(f"check-suites/{run['check_suite_id']}")
        write_json(prefix / "suite.json", suite)
        need(suite["head_sha"] == identity["head"] and suite["app"]["id"] == 15368, "invalid suite")
        by_name = {job["name"]: job for job in jobs}
        need(set(by_name) == CONTEXTS, "missing canonical jobs")
        for job in jobs:
            check = self.api(f"check-runs/{job['id']}")
            need(
                check["head_sha"] == identity["head"]
                and check["check_suite"]["id"] == suite["id"]
                and check["app"]["id"] == 15368
                and check["name"] == job["name"],
                "invalid Actions check",
            )
            write_json(prefix / f"check-{job['id']}.json", check)
        artifacts = self.api(f"actions/runs/{run_id}/artifacts?per_page=100")["artifacts"]
        write_json(prefix / "artifacts.json", artifacts)
        log_path = self.process(
            ["gh", "run", "view", str(run_id), "-R", self.repo, "--attempt", str(attempt), "--log"],
            relative / "actions.log",
        )
        if expected == "hold":
            log = log_path.read_text(errors="replace")
            need(
                result.returncode == 1 and receipt["status"] == "hold"
                and run["conclusion"] == "failure" and by_name["python"]["conclusion"] == "failure"
                and by_name["aitm-ci"]["conclusion"] == "skipped"
                and not any(a["name"].startswith("aitm-ci-evidence-") for a in artifacts)
                and NODE in log and ASSERTION in log and "FAILED" in log,
                "cloud failure did not establish the predeclared behavior and verifier refusal",
            )
        else:
            need(
                result.returncode == 0 and receipt["status"] == "pass"
                and run["conclusion"] == "success"
                and all(job["conclusion"] == "success" for job in jobs)
                and (receipt["base"], receipt["head"], receipt["tested"], receipt["tree"])
                == (self.base, identity["head"], tested["sha"], identity["tree"])
                and (receipt["run_id"], receipt["run_attempt"]) == (run_id, attempt)
                and set(receipt["jobs"]) == CONTEXTS,
                f"exact successful verification unavailable; evidence at {prefix}",
            )
        return prefix


    def fixture_preflight(self, phase, identity, *, expected):
        self.event("local_fixture_preflight_started", phase=phase, **identity)
        test = "packages/aitm-usage/tests/test_grok.py"
        edge = "tools/ci/tia/edges.json"
        self.git("diff", "--exit-code", self.base, "HEAD", "--", edge, test,
                 "tools/ci/pytest_evidence.py", "packages/aitm-usage/uv.lock",
                 "packages/aitm-usage/pyproject.toml")
        source = json.loads(self.git("show", f"{self.base}:{edge}"))
        bindings = [item for item in source["edges"] if item["input"] == FIXTURE]
        need(
            len(bindings) == 1 and bindings[0]["id"] == "grok-headless-fixture"
            and bindings[0]["consumer"] == test and bindings[0]["kind"] == "fixture"
            and self.git("status", "--porcelain") == ""
            and self.git("rev-parse", "HEAD") == identity["head"]
            and self.git("rev-parse", "HEAD^{tree}") == identity["tree"]
            and identity["changes"] == [FIXTURE],
            "exact tracked candidate does not match the declared edge",
        )
        receipt_path = self.out / f"{phase}-fixture-pytest.json"
        env = {
            k: v for k, v in os.environ.items()
            if not k.startswith(("PYTEST_", "PYTHON", "UV_", "GIT_", "AITM_CI_"))
            and k not in {"VIRTUAL_ENV", "__PYVENV_LAUNCHER__"}
        }
        log = self.out / f"{phase}-fixture-pytest.log"
        with tempfile.TemporaryDirectory(prefix="aitm-339-") as scratch:
            path = Path(scratch)
            env.update(
                PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                PYTHONDONTWRITEBYTECODE="1",
                PYTHONPATH=str(self.root / "tools/ci"),
                AITM_CI_PYTEST_EVIDENCE=str(receipt_path),
                UV_PROJECT_ENVIRONMENT=str(path / "venv"),
            )
            command = [
                "uv", "run", "--no-config", "--project", "packages/aitm-usage",
                "--locked", "--python", "3.13.9", "--",
                "python", "-P", "-m", "pytest", "-q", "-p", "pytest_evidence",
                "-p", "no:cacheprovider", "--rootdir", str(self.root),
                "--basetemp", str(path / "fixtures"), test,
            ]
            write_json(self.out / f"{phase}-fixture-command.json", {
                "binding": bindings[0],
                "command": command,
                "identity": identity,
                "observer_blob": self.git("rev-parse", "HEAD:tools/ci/pytest_evidence.py"),
            })
            with log.open("wb") as stream:
                process = subprocess.run(
                    command, cwd=self.root, env=env,
                    stdout=stream, stderr=subprocess.STDOUT, check=False,
                )
        receipt = json.loads(receipt_path.read_text())
        failures = {
            item["nodeid"] for item in receipt["reports"] if item["outcome"] == "failed"
        }
        node = f"{test}::{NODE}"
        need(
            process.returncode == receipt["exit_code"] == expected
            and receipt["deselected"] == [] and node in receipt["collected"]
            and failures == ({node} if expected else set())
            and (not expected or ASSERTION in log.read_text(errors="replace"))
            and self.git("status", "--porcelain") == ""
            and self.git("rev-parse", "HEAD") == identity["head"],
            "bounded fixture module had an unexpected outcome, collection or source drift",
        )
        self.event(
            "local_fixture_preflight_finished", phase=phase, exit_code=expected,
            collected=len(receipt["collected"]), failed=sorted(failures), obligation=node,
        )

    def resume_treatment(self):
        need(self.name == "treatment", "only treatment uses fixture recovery")
        refused = json.loads((self.out / "initial-local-tia.json").read_text())
        need(
            refused["result"]["status"] == "refused"
            and "unclassified or out-of-profile node ID" in refused["plan"]["reasons"][0]
            and not (self.out / "pr-url.txt").exists(),
            "expected isolated advisory refusal before any publication",
        )
        original = json.loads((self.out / "initial-candidate.json").read_text())
        self.fixture_preflight("initial", original, expected=1)
        corrected = self.candidate("corrected", 12789)
        self.fixture_preflight("corrected", corrected, expected=0)
        first = json.loads((self.out / "initial-fixture-pytest.json").read_text())
        second = json.loads((self.out / "corrected-fixture-pytest.json").read_text())
        need(first["collected"] == second["collected"], "local module collection changed")
        self.publish("corrected", corrected)
        final = self.wait_for_terminal("corrected", corrected["head"])
        self.verify("corrected", final, corrected, expected="pass")

    def run(self):
        need(self.git("rev-parse", "HEAD") == self.base, "initial arm not at exact base")
        self.event("edit_started", planned_base=self.base)
        initial = self.candidate("initial", 12790)
        if self.name == "control":
            self.publish("initial", initial)
            first = self.wait_for_terminal("initial", initial["head"])
            self.verify("initial", first, initial, expected="hold")
        else:
            self.preflight("initial", initial, expected=1)
        corrected = self.candidate("corrected", 12789)
        if self.name == "treatment":
            self.preflight("corrected", corrected, expected=0)
        self.publish("corrected", corrected)
        final = self.wait_for_terminal("corrected", corrected["head"])
        self.verify("corrected", final, corrected, expected="pass")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("arm", choices=["control", "treatment"])
    parser.add_argument("--resume-fixture", action="store_true")
    args = parser.parse_args()
    arm = Arm(args.arm)
    if args.resume_fixture:
        arm.resume_treatment()
    else:
        arm.run()
