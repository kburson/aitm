"""Capture source identity for each distinct measured tree and its sole fixture diff."""

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = "packages/aitm-usage/tests/fixtures/grok/headless.json"
records = ROOT / "records"
base = (records / "production-base").read_text().strip()
out = records / "source"
out.mkdir(exist_ok=True)
cases = {"base": base}

for arm in ("control", "treatment"):
    for phase in ("initial", "corrected"):
        data = json.loads((records / arm / f"{phase}-candidate.json").read_bytes())
        cases[f"{arm}-{phase}"] = data["head"]


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT / "lab"), *args])


for label, head in cases.items():
    (out / f"{label}.ls-tree").write_bytes(git("ls-tree", "-r", head))
    (out / f"{label}.commit").write_bytes(git("cat-file", "commit", head))
    (out / f"{label}.fixture").write_bytes(git("show", f"{head}:{FIXTURE}"))
