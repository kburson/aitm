"""Reconcile retained matched #339 identities, workloads, timestamps and attestations."""

import json
import subprocess
from datetime import datetime
from hashlib import sha1, sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "records"
COVERS = {"python-base", "python", "quality", "file-checks", "collect-evidence", "aitm-ci"}
TARGET = "test_headless_projection_is_only_corroboration"
ASSERTION = "assert len(baseline.observations) == 2 and not baseline.diagnostics"
REPO = (OUT / "repository").read_text().strip()
BASE = (OUT / "production-base").read_text().strip()
APP = 15368


def read(path):
    return json.loads(path.read_bytes())


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def instant(value):
    return datetime.fromisoformat(value)


def seconds(start, end):
    return round((instant(end) - instant(start)).total_seconds(), 3)


def hash_bytes(data):
    return sha256(data).hexdigest()


def event(events, kind, phase=None):
    matches = [item for item in events if item["event"] == kind and (phase is None or item.get("phase") == phase)]
    hit, = matches
    return hit["utc"]


def archived(folder, artifact):
    return ZipFile(folder / f"{artifact}.zip")


def job_clocks(jobs):
    result = {}
    for name, job in jobs.items():
        started = job["started_at"]
        completed = job["completed_at"]
        result[name] = {
            "id": job["id"],
            "conclusion": job["conclusion"],
            "created_at": job["created_at"],
            "started_at": started,
            "completed_at": completed,
            "queue_seconds": seconds(job["created_at"], started) if started else None,
            "execution_seconds": seconds(started, completed) if started and completed else None,
        }
    return result


def verify_cryptography(receipt, tested, subject, bundle):
    with TemporaryDirectory(prefix="aitm-339-replay-") as scratch:
        path = Path(scratch)
        candidate = path / "candidate.json"
        signature = path / "attestation.sigstore.json"
        candidate.write_bytes(subject)
        signature.write_bytes(bundle)
        raw = subprocess.check_output([
            "gh", "attestation", "verify", str(candidate), "--hostname", "github.com",
            "--repo", REPO, "--bundle", str(signature), "--signer-workflow",
            f"{REPO}/.github/workflows/ci.yml", "--cert-oidc-issuer",
            "https://token.actions.githubusercontent.com", "--predicate-type",
            "https://slsa.dev/provenance/v1", "--source-ref",
            f"refs/pull/{receipt['pr']}/merge", "--source-digest", tested,
            "--signer-digest", tested, "--deny-self-hosted-runners",
            "--custom-trusted-root", str(OUT / "gh-trusted-root.jsonl"), "--format", "json",
        ])
    verified, = json.loads(raw)
    identity = verified["verificationResult"]
    certificate = identity["signature"]["certificate"]
    assert certificate["sourceRepositoryIdentifier"] == str(receipt["repository_id"])
    assert certificate["runInvocationURI"] == receipt["run"]
    assert certificate["buildTrigger"] == "pull_request"
    assert certificate["runnerEnvironment"] == "github-hosted"
    assert identity["statement"]["subject"] == [
        {"name": "candidate.json", "digest": {"sha256": receipt["subject_digest"]}},
    ]


def verify_attempt(raw, attempt):
    folder = OUT / "hosted" / str(raw["id"])
    here = folder / f"attempt-{attempt}"
    native = read(here / "attempt.json")
    suite = read(folder / "suite.json")
    assert suite["app"]["id"] == APP and suite["head_sha"] == raw["head_sha"]
    assert native["head_sha"] == raw["head_sha"] and native["run_attempt"] == attempt
    assert native["check_suite_id"] == suite["id"] == raw["check_suite_id"]
    jobs = {job["name"]: job for job in read(here / "jobs.json")["jobs"]}
    for name, job in jobs.items():
        check = read(here / f"check-{job['id']}.json")
        assert check["app"]["id"] == APP and check["name"] == name
        assert check["check_suite"]["id"] == suite["id"] and check["head_sha"] == raw["head_sha"]
        assert job["conclusion"] == check["conclusion"]
    artifacts = {}
    for artifact in read(folder / "artifacts.json")["artifacts"]:
        if artifact["name"].endswith(f"-a{attempt}"):
            data = (folder / f"{artifact['name']}.zip").read_bytes()
            assert len(data) == artifact["size_in_bytes"]
            assert artifact["digest"] == "sha256:" + hash_bytes(data)
            artifacts[artifact["name"]] = artifact
    return folder, native, jobs, artifacts


def accepted(arm, run):
    result_folder = OUT / arm
    pass_dir = result_folder / (result_folder / "authorized-pass-path").read_text().strip()
    saved_pr = read(pass_dir / "pr-before.json")
    receipt = read(pass_dir / "trusted-verifier.json")
    tree = read(result_folder / "corrected-candidate.json")["tree"]
    head, tested = saved_pr["head"]["sha"], saved_pr["merge_commit_sha"]
    assert receipt["status"] == "pass" and receipt["repository"] == REPO
    assert receipt["repository_id"] == saved_pr["base"]["repo"]["id"]
    assert receipt["pr"] == saved_pr["number"] and receipt["target"] == "trunk"
    assert saved_pr["state"] == "open" and saved_pr["base"]["sha"] == BASE
    assert receipt["base"] == BASE and receipt["head"] == run["head_sha"] == head
    assert receipt["tested"] == tested and receipt["tree"] == receipt["reviewed_tree"] == tree
    assert receipt["run_id"] == run["id"] and receipt["run_attempt"] == run["run_attempt"]
    completed = read(OUT / f"pr-{receipt['pr']}-final.json")
    synth = read(OUT / f"pr-{receipt['pr']}-final-synthetic.json")
    exact_synth_path = pass_dir / "synthetic.json"
    if exact_synth_path.exists():
        synth = read(exact_synth_path)
    else:
        assert completed["merge_commit_sha"] == tested
    assert synth["sha"] == tested and synth["tree"]["sha"] == tree
    assert [p["sha"] for p in synth["parents"]] == [BASE, head]
    attempt = receipt["run_attempt"]
    folder, native, jobs, arts = verify_attempt(run, attempt)
    assert set(jobs) == COVERS and all(job["conclusion"] == "success" for job in jobs.values())
    assert receipt["jobs"] == {name: job["id"] for name, job in jobs.items()}
    expected_names = {f"aitm-ci-{part}-a{attempt}" for part in ("base", "python", "collector", "evidence")}
    assert set(arts) == expected_names
    name = f"aitm-ci-evidence-a{attempt}"
    meta = arts[name]
    assert meta["id"] == receipt["artifact_id"] and meta["digest"] == receipt["archive_digest"]
    with archived(folder, name) as signed, archived(folder, f"aitm-ci-collector-a{attempt}") as collector:
        assert sorted(signed.namelist()) == ["attestation.sigstore.json", "candidate.json"]
        subject = signed.read("candidate.json")
        bundle = signed.read("attestation.sigstore.json")
        assert collector.read("candidate.json") == subject
    assert hash_bytes(subject) == receipt["subject_digest"]
    document = json.loads(subject)
    assert (document["base"], document["head"], document["tested"], document["tree"]) == (BASE, head, tested, tree)
    assert (document["run"], document["attempt"], document["pr"]) == (run["id"], attempt, receipt["pr"])
    assert document["controls"] == receipt["controls"]
    assert document["result"]["passed"] and document["result"]["failures"] == []
    assert document["result"]["coverage"] == receipt["coverage"]
    assert all(100 * result["covered_lines"] >= 90 * result["num_statements"] for result in receipt["coverage"].values())
    with archived(folder, f"aitm-ci-python-a{attempt}") as python:
        inventory = python.read("pytest.json")
        candidate = json.loads(inventory)
        assert hash_bytes(inventory) == document["inventory"]
        assert hash_bytes(python.read("product-inventory.json")) == document["source_inventory"]
        assert json.loads(python.read("wheel.json"))["digest"] == document["wheel"]
        assert candidate["exit_code"] == 0 and candidate["deselected"] == []
        assert len(set(candidate["collected"])) == len(candidate["collected"]) == document["result"]["tests"]
        assert json.loads(python.read("expected-base.json")) == document["base_identity"]
    with archived(folder, f"aitm-ci-base-a{attempt}") as archive:
        payload = archive.read("base.json")
        assert hash_bytes(payload) == document["baseline"]
        base = json.loads(payload)["evidence"]
        assert base["exit_code"] == 0 and base["deselected"] == []
        assert len(set(base["collected"])) == len(base["collected"]) == document["result"]["baseline_tests"]
    actions_log = (folder / f"attempt-{attempt}" / "actions.log").read_text()
    assert "196 passed in " in actions_log
    assert any(step["name"] == "Build and smoke-test the exact installed wheel" and step["conclusion"] == "success" for step in jobs["python"]["steps"])
    assert receipt["run"] == f"https://github.com/{REPO}/actions/runs/{run['id']}/attempts/{attempt}"
    verify_cryptography(receipt, tested, subject, bundle)
    signed_at = max((meta["created_at"], jobs["aitm-ci"]["completed_at"]), key=instant)
    assert instant(signed_at) <= instant(receipt["verified_at"])
    return (
        {**receipt, "signed_ready_at": signed_at, "run_created_at": run["created_at"], "attempt_started_at": native["run_started_at"], "job_clocks": job_clocks(jobs), "test_counts": document["result"], "hosted_timing": document["timings"], "wheel_digest": document["wheel"]},
        candidate,
        base,
    )


def matched_workload(left, right):
    assert sorted(left["collected"]) == sorted(right["collected"])
    assert left["deselected"] == right["deselected"] == []
    phases = ("nodeid", "when", "outcome", "wasxfail", "skip_reason")
    canonical = lambda evidence: sorted(tuple(row[key] or "" for key in phases) for row in evidence["reports"])
    assert canonical(left) == canonical(right)
    return {
        "tests": len(left["collected"]),
        "phase_reports": len(left["reports"]),
        "node_set_sha256": hash_bytes(json.dumps(sorted(left["collected"])).encode()),
        "phase_outcomes_sha256": hash_bytes(json.dumps(canonical(left)).encode()),
    }



def git_oid(kind, raw):
    return sha1(f"{kind} {len(raw)}\0".encode() + raw).hexdigest()


def check_source(red_candidates, green_candidates):
    source = OUT / "source"
    changed = "packages/aitm-usage/tests/fixtures/grok/headless.json".encode()

    def entries(path):
        return dict((line.split(b"\t", 1)[1], line.split(b"\t", 1)[0]) for line in path.read_bytes().splitlines())

    reference = entries(source / "base.ls-tree")
    base_fixture = json.loads((source / "base.fixture").read_bytes())
    target = "20000000-0000-4000-8000-000000000001"
    for phase, candidates, value in (
        ("initial", red_candidates, 12790), ("corrected", green_candidates, 12789)
    ):
        for arm, candidate in candidates.items():
            label = f"{arm}-{phase}"
            tree = entries(source / f"{label}.ls-tree")
            commit = (source / f"{label}.commit").read_bytes()
            fixture = (source / f"{label}.fixture").read_bytes()
            assert git_oid("commit", commit) == candidate["head"]
            assert commit.splitlines()[0].decode() == "tree " + candidate["tree"]
            assert reference.keys() == tree.keys()
            assert {path for path in tree if tree[path] != reference[path]} == {changed}
            assert tree[changed].split()[0:2] == reference[changed].split()[0:2]
            assert tree[changed].split()[2].decode() == git_oid("blob", fixture) == candidate["fixture_blob"]
            expected = json.loads(json.dumps(list(reversed(base_fixture))))
            record = next(row for row in expected if row["requestId"] == target)
            assert record["usage"]["input_tokens"] == 12789
            record["usage"]["input_tokens"] = value
            assert expected == json.loads(fixture)
    return True


def main():
    assert subprocess.check_output(["gh", "--version"], text=True).split()[:3] == ["gh", "version", "2.97.0"]
    parity = read(OUT / "parity.json")
    assert all(parity[key] for key in (
        "lab_protected_base_and_rules_unchanged", "active_production_workflow_unchanged",
        "effective_production_rules_unchanged", "production_103_issue_unchanged",
    ))
    for path, identity in parity["source_controls"].items():
        source = (OUT / "trusted" / path).read_bytes()
        assert hash_bytes(source) == identity["sha256"]
        assert git_oid("blob", source) == identity["git_blob"]
    approval = read(OUT / "reviewed-tree-disposition.json")
    assert hash_bytes((ROOT / approval["review_path"]).read_bytes()) == approval["review_sha256"]
    linked = read(OUT / "canonical-runs.json")["workflow_runs"]
    grouped = {
        arm: sorted((row for row in linked if row["head_branch"] == f"probe/{arm}"), key=lambda row: (row["created_at"], row["id"]))
        for arm in ("control", "treatment")
    }
    assert len(grouped["control"]) >= 2 and grouped["treatment"]
    red = grouped["control"][0]
    red_dir = OUT / "control" / f"initial-{red['id']}-a1"
    red_receipt = read(red_dir / "trusted-verifier.json")
    assert red_receipt["status"] == "hold" and red_receipt["reason"] == "selected attempt is not complete and successful"
    red_folder, _, red_jobs, red_artifacts = verify_attempt(red, 1)
    assert set(red_jobs) == COVERS
    assert red_jobs["python"]["conclusion"] == "failure"
    assert red_jobs["collect-evidence"]["conclusion"] == "failure"
    assert red_jobs["aitm-ci"]["conclusion"] == "skipped"
    assert not any(name.startswith("aitm-ci-evidence-") for name in red_artifacts)
    red_log = (red_folder / "attempt-1/actions.log").read_text()
    local_log = (OUT / "treatment/initial-fixture-pytest.log").read_text()
    assert "1 failed, 1516 passed" in red_log
    for log in (red_log, local_log):
        assert TARGET in log and ASSERTION in log and "AssertionError: assert (0 == 2)" in log
    red_candidates = {arm:read(OUT / arm / "initial-candidate.json") for arm in grouped}
    green_candidates = {arm:read(OUT / arm / "corrected-candidate.json") for arm in grouped}
    for candidates in (red_candidates, green_candidates):
        assert candidates["control"]["tree"] == candidates["treatment"]["tree"]
        assert candidates["control"]["fixture_blob"] == candidates["treatment"]["fixture_blob"]
        assert candidates["control"]["head"] != candidates["treatment"]["head"]
    assert approval["tree"] == green_candidates["treatment"]["tree"]
    assert check_source(red_candidates, green_candidates)
    assert red["head_sha"] == red_candidates["control"]["head"]
    assert not any(run["head_sha"] == red_candidates["treatment"]["head"] for run in grouped["treatment"])
    refusal = read(OUT / "treatment/initial-local-tia.json")
    assert refusal["plan"]["mode"] == "unavailable" and refusal["result"]["executed"] == 0
    local_red = read(OUT / "treatment/initial-fixture-pytest.json")
    local_green = read(OUT / "treatment/corrected-fixture-pytest.json")
    assert len(local_red["collected"]) == 33 and local_red["collected"] == local_green["collected"]
    assert local_red["exit_code"] == 1 and local_green["exit_code"] == 0
    failures = {r["nodeid"] for r in local_red["reports"] if r["outcome"] == "failed"}
    assert len(failures) == 1 and next(iter(failures)).endswith("::" + TARGET)
    results = {}
    inventories = {}
    for arm, history in grouped.items():
        final, candidate, base = accepted(arm, history[-1])
        events = rows(OUT / arm / "events.jsonl")
        start = event(events, "edit_started")
        publication = event(events, "provider_publish_started", "corrected")
        earliest = history[0]["created_at"]
        assert instant(start) < instant(publication) <= instant(final["verified_at"])
        timings = {
            "edit_to_verified_seconds": seconds(start, final["verified_at"]),
            "edit_to_signed_seconds": seconds(start, final["signed_ready_at"]),
            "first_registration_to_signed_seconds": seconds(earliest, final["signed_ready_at"]),
            "first_registration_to_verified_seconds": seconds(earliest, final["verified_at"]),
            "final_registration_to_verified_seconds": seconds(history[-1]["created_at"], final["verified_at"]),
            "corrected_publish_to_verified_seconds": seconds(publication, final["verified_at"]),
        }
        attempts = []
        for run in history:
            for number in range(1, run["run_attempt"] + 1):
                _, native, jobs, _ = verify_attempt(run, number)
                attempts.append({"run": run["id"], "attempt": number, "head": run["head_sha"], "registered": run["created_at"], "conclusion": native["conclusion"], "job_clocks": job_clocks(jobs)})
        results[arm] = {
            "edit_started_at": start,
            "first_registration_at": earliest,
            "corrected_publish_started_at": publication,
            "timings": timings,
            "final": final,
            "attempts": attempts,
        }
        inventories[arm] = (candidate, base)
    assert results["control"]["final"]["tree"] == results["treatment"]["final"]["tree"]
    delta = {
        key: round(results["control"]["timings"][key] - results["treatment"]["timings"][key], 3)
        for key in results["control"]["timings"]
    }
    actual_pass = delta["edit_to_verified_seconds"] > 0 and len(grouped["control"]) > len(grouped["treatment"])
    return {
        "schema": "aitm.experimental-paired-pr-feedback/v1",
        "qualified": actual_pass,
        "repo": REPO,
        "paired_sample_count": 1,
        "stock_tia_qualified": False,
        "gate_changed": False,
        "base": BASE,
        "red_tree": red_candidates["control"]["tree"],
        "corrected_tree": approval["tree"],
        "red_assertion": ASSERTION,
        "local_obligations": len(local_red["collected"]),
        "control_minus_treatment_seconds": delta,
        "same_workload": {
            "candidate": matched_workload(inventories["control"][0], inventories["treatment"][0]),
            "base": matched_workload(inventories["control"][1], inventories["treatment"][1]),
        },
        "arms": results,
    }


if __name__ == "__main__":
    print(json.dumps(main(), indent=2, sort_keys=True))
