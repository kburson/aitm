"""Render the compact #339 readout from the replayed receipts."""

import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SUMMARY = json.loads((ROOT / "qualification-summary.json").read_bytes())
ARMS = SUMMARY["arms"]
CONTROL = ARMS["control"]
TREATMENT = ARMS["treatment"]


def elapsed(seconds):
    sign = "−" if seconds < 0 else ""
    minutes, remainder = divmod(abs(int(round(seconds))), 60)
    return f"{sign}{minutes}m {remainder:02d}s" if minutes else f"{sign}{remainder}s"


def interval(start, finish):
    return (datetime.fromisoformat(finish) - datetime.fromisoformat(start)).total_seconds()


def selected_event(arm, kind, phase=None):
    path = ROOT / "records" / arm / "events.jsonl"
    found, = (
        item for line in path.read_text().splitlines()
        if (item := json.loads(line))["event"] == kind
        and (phase is None or item.get("phase") == phase)
    )
    return found["utc"]


def value(key):
    return " | ".join(elapsed(x) for x in (
        CONTROL["timings"][key],
        TREATMENT["timings"][key],
        SUMMARY["control_minus_treatment_seconds"][key],
    ))


def coverage(arm, key):
    item = arm["final"]["coverage"][key]
    lines, total = item["covered_lines"], item["num_statements"]
    return f"{lines:,}/{total:,} ({100 * lines / total:.2f}%)"


def link(attempt):
    return f"[{attempt['run']}/{attempt['attempt']}](https://github.com/{SUMMARY['repo']}/actions/runs/{attempt['run']}/attempts/{attempt['attempt']})"


def main():
    assert SUMMARY["qualified"], "the paired qualification criteria did not pass"
    local_red = selected_event("treatment", "local_fixture_preflight_finished", "initial")
    control_red_job = CONTROL["attempts"][0]["job_clocks"]["python"]["completed_at"]
    edit_to_early_red = elapsed(interval(TREATMENT["edit_started_at"], local_red))
    edit_to_cloud_red = elapsed(interval(CONTROL["edit_started_at"], control_red_job))
    faster = elapsed(SUMMARY["control_minus_treatment_seconds"]["edit_to_verified_seconds"])
    body = f"""# #339 Paired exact PR feedback qualification

The explicit Grok fixture preflight reached the trusted full verdict **{faster} sooner** in one protected, matched GitHub PR pair. The local module caught the same behavior failure as hosted CI and the treatment needed one fewer hosted candidate. Both corrected attempts exercised the ordinary full gate and verified the identical source tree. [Qualification plan](2026-11-16-339-exact-pr-feedback-plan.md) · [Recorded preflight recovery](2026-11-16-339-preflight-recovery.md)

| Elapsed interval | Hosted-first control | Fixture preflight | Reduction |
| --- | ---: | ---: | ---: |
| Initial edit start to live trusted full verdict | {value("edit_to_verified_seconds")} |
| Initial edit start to exact signed completion | {value("edit_to_signed_seconds")} |
| First canonical provider registration to exact signed completion | {value("first_registration_to_signed_seconds")} |
| First canonical provider registration to live trusted verdict | {value("first_registration_to_verified_seconds")} |
| Corrected publication start to live trusted verdict | {value("corrected_publish_to_verified_seconds")} |
| Corrected candidate registration to live trusted verdict | {value("final_registration_to_verified_seconds")} |

The first control registration belongs to the real failing candidate. The treatment's first registration belongs to the corrected candidate. Its edit clock includes the initial TIA refusal, diagnosis, both fixed-module checks and the wait for full canonical evidence. The corrected-publication and final-registration rows isolate time on the repaired candidate. The signed endpoint is the later of the provider's signed artifact timestamp and successful signer completion. Hosted queue, job, artifact and verification times are preserved separately in the machine readout.

## Matched failure and repair

Both initial candidates used tree `{SUMMARY["red_tree"]}`. Both corrected candidates used tree `{SUMMARY["corrected_tree"]}` on base `{SUMMARY["base"]}`. The sole tracked difference from base was the Grok headless test fixture. The two-row refresh reversed the row order. The initial edit also changed the first request's input token count from 12789 to 12790, making the declared counts inconsistent. The correction restored 12789 and kept the row refresh.

The existing `test_headless_projection_is_only_corroboration` required two observations without diagnostics. The same assertion reported zero observations in the bounded local run and the hosted control. The hosted Python job reached terminal failure {edit_to_cloud_red} after edit start. The trusted verifier refused the unsuccessful canonical attempt, and its signer was skipped. The local module reported red {edit_to_early_red} after edit start and passed all 33 collected tests after repair. The correction was published only after that local pass.

The stock #143 TIA command refused to run because the current suite policy leaves 12 collected product modules, totaling 250 test IDs, unclassified. An amendment recorded before local fallback or the hosted red outcome pinned the existing `grok-headless-fixture` dependency edge, the unchanged complete `test_grok.py` module, the locked Python 3.13.9 environment and the canonical observer. This result qualifies that explicit fixture preflight. General TIA selection remains unqualified at this production base.

## Full hosted evidence

| Candidate | Canonical attempt | Exact tree verification |
| --- | --- | --- |
| [Control initial](https://github.com/{SUMMARY["repo"]}/pull/1) | {link(CONTROL["attempts"][0])} | Hold. Python and collector failed. Signer skipped. |
| [Control corrected](https://github.com/{SUMMARY["repo"]}/pull/1) | {link(CONTROL["attempts"][-1])} | Pass. All six required Actions checks passed. |
| [Treatment corrected](https://github.com/{SUMMARY["repo"]}/pull/2) | {link(TREATMENT["attempts"][-1])} | Pass. All six required Actions checks passed. |

Both full endpoints retained the same {SUMMARY["same_workload"]["candidate"]["tests"]:,} candidate and {SUMMARY["same_workload"]["base"]["tests"]:,} trusted-base node IDs and matching per-test phase outcomes, with zero deselections. Both helper invocations passed 196 tests. Product coverage was {coverage(CONTROL, "product")} on control and {coverage(TREATMENT, "product")} on treatment. Helper coverage was {coverage(CONTROL, "helpers")} and {coverage(TREATMENT, "helpers")}, respectively. The signed collector and wheel smoke receipts matched their own exact provider identities. Offline Sigstore replay authenticated each signed subject and its distinct PR, attempt and synthetic commit.

The unchanged verifier treats tracked fixtures as controls. The independent narrow disposition binds the identical corrected tree for the lab verifier only. The treatment's verification without that disposition held and was preserved. The first successful authorized check defines each endpoint. The control's immediate post-push PR API readback lagged. The corrected push already registered successfully, and the control clock continued through read-only recovery without another push or restart.

## Scope

The measured gain comes from avoiding one hosted run of the deliberately failing edit. The paired test uses one fixture edge, known correction and disposable protected repository. It supplies no fleet latency percentile, no 3,000-test forecast and no evidence for preventing unrelated cancellations or GitHub synthetic merge refreshes. The eight observed production PRs in #337 still give the historical baseline of 22m 01s p50 and 45m 55s p95 from first registration through exact signed evidence. [#337 production readout](https://github.com/kburson/aitm/blob/c34a9a9fba8406bf40115edfd7c7f939b6b2529d/.aitm/stories/003/337/plan/production-readout.md)

Production #103's issue, canonical source and state, verifier, policy and effective trunk rules matched the pre-experiment readbacks. The lab's protected base remained frozen and both lab PRs stayed open through evidence capture. No PR was merged. [Evidence archive](exact-pr-feedback-evidence.zip) · [Machine readout](qualification-summary.json) · [Reproduction](reproduction.md)
"""
    print(body, end="")


if __name__ == "__main__":
    main()
