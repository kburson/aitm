#!/bin/bash
set -euo pipefail
root=$(cd "$(dirname "$0")/.." && pwd)
repo=$1
base=$(git -C "$root/lab" rev-parse HEAD)
production=kburson/aitm
cd "$root"
printf '%s\n' "$base" > records/production-base
printf '%s\n' "$repo" > records/repository
gh --version > records/gh-version.txt
uv --version > records/uv-version.txt
uname -srm > records/local-platform.txt
gh api "repos/$production/branches/trunk" > records/production-branch-before.json
test "$(jq -r .commit.sha records/production-branch-before.json)" = "$base"
gh api "repos/$production/rules/branches/trunk" > records/production-rules-before.json
gh api "repos/$production/rulesets/26821811" > records/production-ruleset-before.json
gh api "repos/$production/actions/workflows/ci.yml" > records/production-workflow-before.json
gh api "repos/$production/issues/103" --jq '{number,title,body,state}' > records/production-issue-103-before.json
jq '{name,target,enforcement,bypass_actors,conditions,rules} | .rules += [{
  type:"required_status_checks",
  parameters:{
    strict_required_status_checks_policy:false,
    required_status_checks:(
      ["python-base","python","quality","file-checks","collect-evidence","aitm-ci"] |
      map({context:.,integration_id:15368})
    )
  }
}]' records/production-ruleset-before.json > records/lab-rules-request.json
gh repo create "$repo" --public --description 'Disposable #133 exact PR feedback qualification on public AITM source' > records/lab-create.txt
gh api --method PUT "repos/$repo/actions/permissions" -F enabled=false
git -C lab remote add origin "git@github.com:$repo.git"
git -C lab push -u origin trunk
gh repo edit "$repo" --default-branch trunk --enable-merge-commit=true --enable-squash-merge=true --enable-rebase-merge=true
gh api --method POST "repos/$repo/rulesets" --input records/lab-rules-request.json > records/lab-ruleset.json
gh api --method PUT "repos/$repo/actions/permissions" -F enabled=true -f allowed_actions=all
gh api "repos/$repo/actions/permissions" > records/lab-actions.json
gh api "repos/$repo/branches/trunk" > records/lab-branch.json
gh api "repos/$repo/rules/branches/trunk" > records/lab-rules.json
gh api "repos/$repo/actions/workflows/ci.yml" > records/lab-workflow.json
jq -e --arg base "$base" '.protected and .commit.sha == $base' records/lab-branch.json > /dev/null
jq -e '.state == "active" and .path == ".github/workflows/ci.yml"' records/lab-workflow.json > /dev/null
jq -e '[.[] | select(.type=="required_status_checks") | .parameters.required_status_checks[] | select(.integration_id==15368)] | length == 6' records/lab-rules.json > /dev/null
test "$repo" != "$production"
git -C lab worktree add -b probe/control "$root/control" "$base"
git -C lab worktree add -b probe/treatment "$root/treatment" "$base"
