"""Verify an authorized exact disposable fixture tree at the first observed green."""

import argparse
import json
import subprocess
import sys
import time
from datetime import UTC, datetime
from hashlib import sha256
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]


def get(path):
    return json.loads(path.read_bytes())


def event(path, kind, **data):
    with path.open("a") as f:
        f.write(json.dumps({"event": kind, "utc": datetime.now(UTC).isoformat(), **data}) + "\n")


def main(arm):
    records = ROOT / "records"
    out = records / arm
    repo = (records / "repository").read_text().strip()
    workflow = get(records / "lab-workflow.json")["id"]

    def api(route):
        return json.loads(subprocess.check_output(["gh", "api", f"repos/{repo}/{route}"]))

    assert repo == "kburson/aitm-feedback-339"
    deadline = time.monotonic() + 1800
    tried = set()
    while time.monotonic() < deadline:
        required = (out / "pr-url.txt", out / "corrected-candidate.json", records / "reviewed-tree-disposition.json")
        if all(p.exists() and p.stat().st_size for p in required):
            branch = quote(f"probe/{arm}", safe="")
            runs = api(f"actions/workflows/{workflow}/runs?event=pull_request&branch={branch}&per_page=100")
            pr = int(required[0].read_text().strip().rsplit("/", 1)[1])
            approval = get(required[2])
            tree = get(required[1])["tree"]
            assert approval["tree"] == tree and approval["repository"] == repo
            review = ROOT / approval["review_path"]
            assert approval["review_sha256"] == sha256(review.read_bytes()).hexdigest()
            pull = api(f"pulls/{pr}")
            head = pull["head"]["sha"]
            candidates = [r for r in runs["workflow_runs"] if r["head_sha"] == head]
            if candidates:
                run = max(candidates, key=lambda r: (r["created_at"], r["id"]))
                key = run["id"], run["run_attempt"], pull["merge_commit_sha"]
                if run["status"] == "completed" and run["conclusion"] == "success" and key not in tried:
                    tried.add(key)
                    target = out / f"reviewed-{key[0]}-a{key[1]}-{key[2]}"
                    target.mkdir()
                    (target / "pr-before.json").write_text(json.dumps(pull, indent=2) + "\n")
                    event(out / "reviewed-events.jsonl", "verification_start", run=key[0], attempt=key[1], synthetic=key[2])
                    cmd = [
                        sys.executable, str(ROOT / "lab/tools/ci/verify_pr.py"),
                        "--repo", repo, "--pr", str(pr), "--target", "trunk",
                        "--reviewed-tree", tree, "--output", str(target / "trusted-verifier.json"),
                    ]
                    with (target / "trusted-verifier.log").open("wb") as log:
                        result = subprocess.run(cmd, cwd=ROOT / "lab", stdout=log, stderr=subprocess.STDOUT)
                    receipt = get(target / "trusted-verifier.json")
                    event(out / "reviewed-events.jsonl", "verification_result", run=key[0], attempt=key[1], result=receipt["status"], verified_at=receipt["verified_at"])
                    if result.returncode == 0:
                        assert (receipt["head"], receipt["tested"], receipt["tree"], receipt["run_id"], receipt["run_attempt"]) == (
                            head, key[2], tree, key[0], key[1]
                        )
                        (out / "authorized-pass-path").write_text(target.name + "\n")
                        return
                    print(arm, key, receipt, flush=True)
        time.sleep(4)
    raise TimeoutError(f"no authorized exact verdict for {arm}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("arm", choices=["control", "treatment"])
    main(parser.parse_args().arm)
