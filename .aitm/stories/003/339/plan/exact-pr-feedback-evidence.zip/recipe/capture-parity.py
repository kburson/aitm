"""Capture live production controls before/after without touching production."""

import json
import subprocess
from hashlib import sha256
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "records"
LAB = ROOT / "lab"
PRODUCTION = "kburson/aitm"

CONTROLS = [
    ".github/workflows/ci.yml",
    ".github/workflows/fast-story-shadow.yml",
    ".github/workflows/scheduled-full-shadow.yml",
    "packages/aitm-usage/pyproject.toml",
    "packages/aitm-usage/uv.lock",
    "tools/ci/file_checks.py",
    "tools/ci/policy.json",
    "tools/ci/python_gate.py",
    "tools/ci/pytest_evidence.py",
    "tools/ci/verify_pr.py",
    "tools/ci/tia/local.py",
    "tools/ci/tia/edges.json",
    "tools/ci/tia/suites.json",
]


def shell(*args):
    return subprocess.check_output(args)


def git(*args):
    return shell("git", "-C", str(LAB), *args)


def api(repo, route, path):
    raw = shell("gh", "api", f"repos/{repo}/{route}")
    data = json.loads(raw)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
    return data


def main():
    repo = (OUT / "repository").read_text().strip()
    base = (OUT / "production-base").read_text().strip()
    before = json.loads((OUT / "production-branch-before.json").read_bytes())
    after = api(PRODUCTION, "branches/trunk", OUT / "production-branch-after.json")
    final = after["commit"]["sha"]
    assert before["protected"] and before["commit"]["sha"] == base and after["protected"]
    git("fetch", "--quiet", "production", "refs/heads/trunk:refs/remotes/production/trunk")
    assert git("rev-parse", "refs/remotes/production/trunk").decode().strip() == final
    config = {
        "rules": "rules/branches/trunk",
        "ruleset": "rulesets/26821811",
        "workflow": "actions/workflows/ci.yml",
        "issue-103": "issues/103",
    }
    for name, route in config.items():
        data = api(PRODUCTION, route, OUT / f"production-{name}-after.json")
        expected = json.loads((OUT / f"production-{name}-before.json").read_bytes())
        if name == "workflow":
            keys = ("id", "path", "state", "name")
            data, expected = [{key: doc[key] for key in keys} for doc in (data, expected)]
        if name == "issue-103":
            data = {key: data[key] for key in expected}
        assert data == expected, name
    lab = api(repo, "branches/trunk", OUT / "lab-branch-after.json")
    assert lab["protected"] and lab["commit"]["sha"] == base
    for name, route in (("rules", "rules/branches/trunk"), ("workflow", "actions/workflows/ci.yml")):
        actual = api(repo, route, OUT / f"lab-{name}-after.json")
        initial = json.loads((OUT / f"lab-{name}.json").read_bytes())
        assert actual == initial, name
    paths = {}
    for path in CONTROLS:
        raw = git("show", f"{base}:{path}")
        assert raw == git("show", f"{final}:{path}"), path
        assert raw == git("show", f"HEAD:{path}"), path
        record = OUT / "trusted" / path
        record.parent.mkdir(parents=True, exist_ok=True)
        record.write_bytes(raw)
        paths[path] = {"sha256": sha256(raw).hexdigest(), "git_blob": git("rev-parse", f"{base}:{path}").decode().strip()}
    result = {
        "production_before": base,
        "production_after": final,
        "lab_repository": repo,
        "lab_base": lab["commit"]["sha"],
        "active_production_workflow_unchanged": True,
        "effective_production_rules_unchanged": True,
        "production_103_issue_unchanged": True,
        "lab_protected_base_and_rules_unchanged": True,
        "source_controls": paths,
    }
    (OUT / "parity.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
