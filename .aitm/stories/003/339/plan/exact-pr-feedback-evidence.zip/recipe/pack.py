"""Package the governed experiment outputs and an internal SHA-256 manifest."""

from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
NAMES = (
    "2026-11-16-339-exact-pr-feedback-plan.md",
    "2026-11-16-339-preflight-recovery.md",
    "2026-11-16-339-exact-pr-feedback-results.md",
    "qualification-summary.json",
    "reproduction.md",
)


def write(archive, name, raw):
    info = ZipInfo(name, date_time=(2026, 11, 16, 0, 0, 0))
    info.compress_type = ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    archive.writestr(info, raw, compresslevel=9)


paths = [ROOT / name for name in NAMES]
for group in ("records", "recipe"):
    paths.extend(
        path for path in (ROOT / group).rglob("*")
        if path.is_file() and path.suffix != ".pyc" and ".DS_Store" != path.name
    )
lines = []
with ZipFile(ROOT / "exact-pr-feedback-evidence.zip", mode="w") as archive:
    for path in sorted(paths):
        name = path.relative_to(ROOT).as_posix()
        raw = path.read_bytes()
        write(archive, name, raw)
        lines.append(f"{sha256(raw).hexdigest()}  {name}")
    write(archive, "SHA256SUMS", ("\n".join(lines) + "\n").encode())
