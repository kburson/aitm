#!/usr/bin/env bash
set -eu
root=$1
label=$2
source=$3
cd "$source"
source=$(pwd -P)
out="$root/results/$label"
mkdir -p "$out/tmp" "$out/cache"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 AITM_CI_CHILD_EVIDENCE=1
export TMPDIR="$out/tmp" UV_CACHE_DIR="$out/cache"
uv sync --project packages/aitm-usage --locked --python 3.13.9 > "$out/setup.log" 2>&1
if [ "$label" != serial ]; then
    touch "$out/ready"
    seconds=0
    while [ ! -f "$root/results/start-shards" ]; do
        if [ "$seconds" -ge 120 ]; then printf 'Shard startup timed out\n' >&2; exit 1; fi
        sleep 1
        seconds=$((seconds + 1))
    done
fi
for pair in product:packages/aitm-usage/tests ci:tools/ci/tests board:tools/board_sync/tests dashboard:tools/story_dashboard/tests native:packages/aitm-usage/native-tests; do
    profile=${pair%%:*}
    target=${pair#*:}
    export PYTHONPATH="$source:$source/tools/ci"
    if [ "$profile" = native ]; then export PYTHONPATH="$PYTHONPATH:$source/packages/aitm-usage/tests"; fi
    if [ "$label" != serial ]; then
        ids="$root/ids/$label-$profile"
        if [ ! -s "$ids" ]; then continue; fi
        target="@$ids"
    fi
    export AITM_CI_PYTEST_EVIDENCE="$out/$profile.json"
    rc=0
    date +%s > "$out/$profile.start"
    if [ "$label" != serial ]; then python3.13 -c 'import time; print(time.time_ns())' > "$out/$profile.start-ns"; fi
    packages/aitm-usage/.venv/bin/python -m pytest -c packages/aitm-usage/pyproject.toml --rootdir "$source" -p no:cacheprovider -p pytest_evidence --basetemp "$out/$profile-fixtures" -q "$target" > "$out/$profile.log" 2>&1 || rc=$?
    if [ "$label" != serial ]; then python3.13 -c 'import time; print(time.time_ns())' > "$out/$profile.end-ns"; fi
    date +%s > "$out/$profile.end"
    printf '%s %s exit=%s\n' "$label" "$profile" "$rc"
    tail -5 "$out/$profile.log"
done
git diff --exit-code HEAD
