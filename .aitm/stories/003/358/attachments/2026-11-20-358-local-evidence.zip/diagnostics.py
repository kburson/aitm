from pathlib import Path
import argparse
import json
import signal
import subprocess

args = argparse.ArgumentParser()
args.add_argument("root", type=Path)
root = args.parse_args().root
history = "tools/story_dashboard/tests/test_timing.py::TimingMetrics::test_real_seed_parity_at_historical_pin"
service = "packages/aitm-usage/tests/test_service_process.py::test_real_service_crash_enrollment_and_private_state"
unit = "packages/aitm-usage/tests/test_grok_pricing.py::test_grok_rate_classes_do_not_use_claude_defaults"


def command(label, checkout, target):
    return ["bash", str(root / "replay-history.sh"), str(root), label, checkout, target]


# A foreground Python parent owns launching and waiting. An installed handler
# is reset to default dispositions across exec rather than preserving SIG_IGN.
signal.signal(signal.SIGINT, signal.default_int_handler)
preflight = {
    "foreground": subprocess.check_output(
        ["python3.13", "-c", "import signal; print(signal.getsignal(signal.SIGINT))"], text=True
    ).strip(),
    "noninteractive_shell_background": subprocess.check_output(
        ["bash", "-c", "python3.13 -c 'import signal; print(signal.getsignal(signal.SIGINT))' & wait"], text=True
    ).strip(),
}
assert preflight["foreground"] == "<built-in function default_int_handler>"
assert preflight["noninteractive_shell_background"] == "1"
subprocess.run(command("standalone-history-serial", "clean-a", history), check=True)
subprocess.run(command("standalone-service-serial", "clean-a", service), check=True)
background = subprocess.run(
    ["bash", "-c", '"$@" & pid=$!; wait "$pid"', "_", *command("shell-background-service", "clean-c", service)],
    check=False,
)
assert background.returncode == 1
processes = [
    subprocess.Popen(command("standalone-history-concurrent", "clean-b", history), start_new_session=True),
    subprocess.Popen(command("standalone-fast-concurrent", "clean-a", unit), start_new_session=True),
    subprocess.Popen(command("standalone-service-concurrent", "clean-c", service), start_new_session=True),
]
exits = [process.wait() for process in processes]
assert exits == [0, 0, 0], exits
labels = [
    "standalone-history-serial", "standalone-service-serial", "shell-background-service",
    "standalone-history-concurrent", "standalone-fast-concurrent", "standalone-service-concurrent",
]
summary = {"signal_probe": preflight, "replays": {}}
for label in labels:
    out = root / "replay" / label
    receipt = json.loads((out / "evidence.json").read_bytes())
    summary["replays"][label] = {
        "exit_code": receipt["exit_code"], "collected": receipt["collected"],
        "signal_handler": (out / "sigint").read_text().strip(),
        "start_ns": int((out / "start").read_text()),
        "end_ns": int((out / "end").read_text()),
    }
assert summary["replays"]["shell-background-service"]["signal_handler"] == "1"
print(json.dumps(summary, indent=2))
(root / "replay" / "diagnostics.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
