#!/usr/bin/env bash
set -eu
root=$1
replay() {
    local label=$1 clone=$2 target=$3
    cd "$root/$clone"
    local checkout
    checkout=$(pwd -P)
    local out="$root/replay/$label"
    mkdir -p "$out/tmp" "$out/cache"
    test ! -e .git/objects/info/alternates
    git cat-file -e "17761cc^{commit}"
    export TMPDIR="$out/tmp" UV_CACHE_DIR="$out/cache" PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
    export PYTHONPATH="$checkout:$checkout/tools/ci" AITM_CI_CHILD_EVIDENCE=1
    export AITM_CI_PYTEST_EVIDENCE="$out/evidence.json"
    uv sync --project packages/aitm-usage --locked --python 3.13.9 > "$out/setup.log" 2>&1
    packages/aitm-usage/.venv/bin/python -c 'import signal; print(signal.getsignal(signal.SIGINT))' > "$out/sigint"
    python3.13 -c 'import time; print(time.time_ns())' > "$out/start"
    local rc=0
    packages/aitm-usage/.venv/bin/python -m pytest -c packages/aitm-usage/pyproject.toml --rootdir "$checkout" \
      -p no:cacheprovider -p pytest_evidence --basetemp "$out/fixtures" -q "$target" > "$out/test.log" 2>&1 || rc=$?
    python3.13 -c 'import time; print(time.time_ns())' > "$out/end"
    printf '%s %s\n' "$label" "$rc"
    cat "$out/test.log"
    return "$rc"
}
replay "$2" "$3" "$4"
