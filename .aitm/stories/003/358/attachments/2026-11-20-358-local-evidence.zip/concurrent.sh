#!/usr/bin/env bash
set -eu
root=$1
while [ ! -f "$root/results/serial/native.end" ]; do
  sleep 5
done
date +%s > "$root/results/concurrent.start"
pids=()
for category in fast-unit local-integration systems-integration; do
  bash "$root/run.sh" "$root" "$category" "$root/$category" > "$root/results/$category.log" 2>&1 &
  pids+=("$!")
done
result=0
for pid in "${pids[@]}"; do
  wait "$pid" || result=1
done
date +%s > "$root/results/concurrent.end"
for category in fast-unit local-integration systems-integration; do
  cat "$root/results/$category.log"
done
exit "$result"
