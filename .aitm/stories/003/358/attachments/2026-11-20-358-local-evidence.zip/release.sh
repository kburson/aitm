#!/usr/bin/env bash
set -eu
root=$1
until [ -f "$root/results/concurrent.start" ]; do sleep 5; done
for attempt in {1..100}; do
    if [ -f "$root/results/fast-unit/ready" ] && [ -f "$root/results/local-integration/ready" ] && [ -f "$root/results/systems-integration/ready" ]; then
        touch "$root/results/start-shards"
        exit 0
    fi
    sleep 1
done
printf 'Shard setup did not reach the launch barrier\n' >&2
exit 1
