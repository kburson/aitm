from collections import Counter, defaultdict
from pathlib import Path
import argparse
import csv
import hashlib
import json
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("root", type=Path)
args = parser.parse_args()
root = args.root.resolve()
profiles = ("product", "ci", "board", "dashboard", "native")
categories = ("fast-unit", "slow-unit", "local-integration", "systems-integration")
source = "9843874bd00ffa1255b3595987106d5af51dceb3"
tree = "b8ca66991842e6b360cf09f0e36b25c693d48390"

with (root / "register.tsv").open(newline="") as f:
    assigned = defaultdict(set)
    by_profile = defaultdict(set)
    for row in csv.DictReader(f, delimiter="\t"):
        if row["darwin"] == "absent":
            continue
        profile, category, nodeid = row["profile"], row["category"], row["nodeid"]
        assert nodeid not in by_profile[profile]
        by_profile[profile].add(nodeid)
        assigned[category, profile].add(nodeid)

assert sum(map(len, by_profile.values())) == 2314
all_phases = {layout: {} for layout in ("serial", "parallel")}
all_children = {layout: Counter() for layout in all_phases}
runs = []


def read(label, profile, expected):
    checkout = root / label
    actual = subprocess.check_output(["git", "-C", str(checkout), "show", "-s", "--format=%H %T", "HEAD"], text=True).strip()
    assert actual == f"{source} {tree}"
    subprocess.run(["git", "-C", str(checkout), "diff", "--quiet", "HEAD"], check=True)
    folder = root / "results" / label
    receipt = folder / f"{profile}.json"
    payload = json.loads(receipt.read_bytes())
    assert payload["schema"] == "aitm.pytest-evidence/v1"
    assert not payload["deselected"] and len(set(payload["collected"])) == len(payload["collected"])
    actual_set = set(payload["collected"])
    assert actual_set == expected, (label, profile, sorted(expected - actual_set), sorted(actual_set - expected))
    phases = defaultdict(Counter)
    for report in payload["reports"]:
        nodeid = report["nodeid"]
        assert nodeid in expected
        status = (report["when"], report["outcome"], report["wasxfail"], report["skip_reason"])
        phases[nodeid][status] += 1
    assert phases.keys() == expected, (label, profile, sorted(expected - phases.keys()))
    for test, phase_set in phases.items():
        names = {key[0] for key in phase_set.keys()}
        skipped = any(phase == "setup" and outcome == "skipped" for phase, outcome, *_ in phase_set)
        if payload["exit_code"] == 0:
            assert names == ({"setup", "teardown"} if skipped else {"setup", "call", "teardown"}), (label, profile, test)
    children = Counter((entry["label"], entry["returncode"]) for entry in payload["children"])
    started = int((folder / f"{profile}.start").read_text())
    finished = int((folder / f"{profile}.end").read_text())
    result = {
        "execution": label, "profile": profile,
        "tests": len(expected), "phase_reports": sum(sum(v.values()) for v in phases.values()),
        "exit_code": payload["exit_code"],
        "started_epoch_second": started, "finished_epoch_second": finished, "elapsed_seconds": finished - started,
        "sha256": hashlib.sha256(receipt.read_bytes()).hexdigest(),
        "checks": {outcome: sum(any(item[1] == outcome for item in counts) for counts in phases.values()) for outcome in ("failed", "skipped")},
    }
    runs.append(result)
    return phases, children


def record(layout, label, profile, expected):
    phases, children = read(label, profile, expected)
    overlap = all_phases[layout].keys() & phases.keys()
    assert not overlap, (layout, label, profile, overlap)
    all_phases[layout].update(phases)
    all_children[layout].update(children)


for profile, ids in by_profile.items():
    record("serial", "serial", profile, ids)
for category in categories:
    for profile in profiles:
        ids = assigned[category, profile]
        if ids:
            record("parallel", category, profile, ids)
        else:
            assert not (root / "results" / category / f"{profile}.json").exists()
assert all_phases["serial"].keys() == all_phases["parallel"].keys()
phase_deltas = []
for nodeid, before in all_phases["serial"].items():
    after = all_phases["parallel"][nodeid]
    if before != after:
        phase_deltas.append({
            "nodeid": nodeid,
            "serial": [[*phase, number] for phase, number in before.items()],
            "parallel": [[*phase, number] for phase, number in after.items()],
        })
labels = ("fast-unit", "local-integration", "systems-integration")
three_start_ns = max(int((root / "results" / label / "product.start-ns").read_text()) for label in labels)
three_end_ns = min(int((root / "results" / label / "product.end-ns").read_text()) for label in labels)
serial = [r for r in runs if r["execution"] == "serial"]
parallel = [r for r in runs if r["execution"] != "serial"]
serial_wall = max(r["finished_epoch_second"] for r in serial) - min(r["started_epoch_second"] for r in serial)
parallel_wall = max(r["finished_epoch_second"] for r in parallel) - min(r["started_epoch_second"] for r in parallel)
result = {
    "schema": "aitm.358-isolation-experiment/v1",
    "source": {"commit": source, "tree": tree},
    "host": {"os": "macOS 26.6.2", "arch": "arm64", "filesystem": "APFS", "python": "3.13.9",
             "pytest": "9.2.0", "uv": "0.10.6"},
    "inventory_source": "accepted #357 exact Darwin register",
    "register_sha256": hashlib.sha256((root / "register.tsv").read_bytes()).hexdigest(),
    "parallel_category_totals": {category: sum(len(assigned[category, profile]) for profile in profiles) for category in categories},
    "nodeids_per_layout": len(all_phases["serial"]),
    "phase_report_differences": phase_deltas,
    "observed_skips": {
        layout: [{"nodeid": n, "reasons": sorted({status[3] for status in phases if status[1] == "skipped"})}
                 for n, phases in by_nodeid.items() if any(status[1] == "skipped" for status in phases)]
        for layout, by_nodeid in all_phases.items()
    },
    "children": {layout: [{"label": label, "returncode": code, "count": n}
                          for (label, code), n in sorted(results.items())]
                 for layout, results in all_children.items()},
    "outcomes_identical": not phase_deltas and all_children["serial"] == all_children["parallel"],
    "all_exits_zero": all(r["exit_code"] == 0 for r in runs),
    "elapsed": {"serial_seconds": serial_wall, "parallel_seconds": parallel_wall,
                "three_product_shards_overlap_seconds": round(max(0, three_end_ns - three_start_ns) / 10**9, 3),
                "parallel_setup_and_execution_seconds": int((root / "results/concurrent.end").read_text()) - int((root / "results/concurrent.start").read_text())},
    "runs": runs,
}
print(json.dumps(result, indent=2, sort_keys=True))
