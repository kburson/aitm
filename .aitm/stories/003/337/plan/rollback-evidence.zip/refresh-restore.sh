#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
out=records/restore-superseded
test ! -e "$out"
jq -e '.status=="hold"' records/restored/verify-premerge.json >/dev/null
mv records/restore "$out"
mv records/restored "$out/premerge-hold"
cp records/complete-restore.log "$out/premerge-hold.log"
mv restore-review.md "$out/restore-review-first.md"
gh api "repos/$repo/pulls/2" > "$out/pr-after-ref-change.json"
new_tested=$(jq -r .merge_commit_sha "$out/pr-after-ref-change.json")
old_tested=$(jq -r .tested "$out/trusted-verifier.json")
test "$new_tested" != "$old_tested"
gh api "repos/$repo/git/commits/$new_tested" > "$out/rebuilt-commit.json"
gh api "repos/$repo/git/ref/pull/2/merge" > "$out/rebuilt-ref.json"
jq -e --arg tested "$new_tested" '.object.sha==$tested' "$out/rebuilt-ref.json" >/dev/null
diff <(jq -S '{tree:.tree.sha,parents:[.parents[].sha]}' "$out/tested-commit.json") \
     <(jq -S '{tree:.tree.sha,parents:[.parents[].sha]}' "$out/rebuilt-commit.json")
base=$(cat "$out/base")
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$base"
mkdir records/restore
cp "$out"/{base,pr-url,pr-open.json} records/restore/
git -C lab switch probe/restore
test "$(git -C lab rev-parse HEAD)" = "$(cat "$out/head")"
git -C lab commit --allow-empty -qm 'Refresh disposable restore evidence after GitHub rebuilt the tested merge'
git -C lab rev-parse HEAD > records/restore/head
git -C lab push origin probe/restore
git -C lab switch --detach "$base"
