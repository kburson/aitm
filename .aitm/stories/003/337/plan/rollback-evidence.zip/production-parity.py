"""Read production GitHub and compare its gate controls to the actual preflight."""

import json
import subprocess
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
PLANNING = ROOT.parent / "planning"
RECORDS = ROOT / "records"
CONTROLS = (
    ".github/workflows/ci.yml",
    ".github/workflows/scheduled-full-shadow.yml",
    ".github/workflows/fast-story-shadow.yml",
    "tools/ci/verify_pr.py",
    "tools/ci/python_gate.py",
    "tools/ci/policy.json",
    "tools/ci/pytest_evidence.py",
    "tools/ci/file_checks.py",
    "tools/ci/file-lint",
    "tools/ci/ci_advisory.py",
    "tools/ci/ci_incident.py",
    "tools/ci/ci_recovery.py",
    "tools/ci/ci_scheduled_shadow.py",
    "tools/ci/run_scheduled_shadow.sh",
    "tools/ci/ci_fast_story_shadow.py",
    "packages/aitm-usage/uv.lock",
    "packages/aitm-usage/pyproject.toml",
)


def output(*args):
    return subprocess.check_output(args)


def git(*args):
    return output("git", "-C", str(PLANNING), *args).decode().strip()


def provider(path):
    return json.loads(output("gh", "api", "repos/kburson/aitm/" + path))


before = (RECORDS / "production-base").read_text().strip()
preflight = json.loads((RECORDS / "production-branch-before.json").read_bytes())
assert preflight["commit"]["sha"] == before and preflight["protected"]
git("fetch", "--quiet", "origin", "refs/heads/trunk:refs/remotes/origin/trunk")
head = git("rev-parse", "origin/trunk")
branch = provider("branches/trunk")
assert branch["commit"]["sha"] == head and branch["protected"]
before_oids = {path: git("rev-parse", f"{before}:{path}") for path in CONTROLS}
after_oids = {path: git("rev-parse", f"{head}:{path}") for path in CONTROLS}
assert after_oids == before_oids
rules = provider("rules/branches/trunk")
ruleset = provider("rulesets/26821811")
assert rules == json.loads((RECORDS / "production-rules-before.json").read_bytes())
assert ruleset == json.loads((RECORDS / "production-ruleset-before.json").read_bytes())
with ZipFile(ROOT / "production/production-evidence.zip") as archive:
    initial_workflow = json.loads(archive.read("raw/trusted/canonical-workflow.json"))
workflow = provider("actions/workflows/ci.yml")
for key in ("id", "name", "path", "state"):
    assert workflow[key] == initial_workflow[key], key
print(
    json.dumps(
        {
            "before": before,
            "after": head,
            "canonical_workflow": {
                key: workflow[key] for key in ("id", "name", "path", "state")
            },
            "controls": after_oids,
            "effective_rules": rules,
            "rules_unchanged": True,
            "controls_unchanged": True,
        },
        indent=2,
        sort_keys=True,
    )
)
