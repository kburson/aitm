#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
out=records/ordinary-after-restore
mkdir -p "$out"
landed=$(jq -r .sha records/restored/merged.json)
old_head=$(cat records/ordinary/head)
old_base=$(cat records/ordinary/base)
gh api "repos/$repo/pulls/4" > "$out/stale-pr.json"
test "$(jq -r .head.sha "$out/stale-pr.json")" = "$old_head"
observed_base=$(jq -r .base.sha "$out/stale-pr.json")
[[ "$observed_base" == "$old_base" || "$observed_base" == "$landed" ]]
gh api "repos/$repo/branches/trunk" > "$out/current-trunk.json"
test "$(jq -r .commit.sha "$out/current-trunk.json")" = "$landed"
test "$(git -C lab rev-parse HEAD)" = "$landed"
if python3 lab/tools/ci/verify_pr.py --repo "$repo" --pr 4 --target trunk --output "$PWD/$out/stale-verifier.json" \
    > "$out/stale-verifier.log" 2>&1; then
    echo 'Unchanged verifier accepted superseded canonical evidence'
    exit 1
fi
jq -e '.status=="hold"' "$out/stale-verifier.json" >/dev/null
if gh api --include "repos/$repo/pulls/4/merge" --method PUT -f sha="$old_head" -f merge_method=merge \
    > "$out/stale-merge.log" 2>&1; then
    echo 'Unexpectedly merged ordinary stale head'
    exit 1
fi
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$landed"
gh api "repos/$repo/rulesets/rule-suites?per_page=100" > "$out/stale-rule-suites.json"
git -C lab switch probe/ordinary
test "$(git -C lab rev-parse HEAD)" = "$old_head"
git -C lab merge --no-edit --no-ff "$landed"
git -C lab rev-parse HEAD > "$out/fresh-head"
git -C lab push origin probe/ordinary
git -C lab switch --detach "$landed"
