"""Check and retain the bounded #337 production path and native rollback evidence."""

import json
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
RECORDS = ROOT / "records"
PLAN = "2026-11-15-337-full-pr-and-rollback-plan.md"
REPORT = "2026-11-15-337-full-pr-and-rollback-results.md"


def load(name):
    return json.loads((RECORDS / name).read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def seconds(end, start):
    return int(
        (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds()
    )


def duration(value):
    minutes, secs = divmod(value, 60)
    return f"{minutes}m {secs:02}s"


def native_target():
    restore = load("restore/trusted-verifier.json")
    old = load("ordinary/trusted-verifier.json")
    fresh = load("ordinary-fresh/trusted-verifier.json")
    landed = load("restored/commit.json")
    push = load("restored/push/advisory.json")
    release = load("release/release-response.json")
    ack = load("release/acknowledgment.json")
    assert restore["status"] == old["status"] == fresh["status"] == "pass"
    assert old["base"] == restore["base"] != fresh["base"]
    assert len({old["head"], fresh["head"]}) == 2
    assert fresh["base"] == landed["sha"] == push["sha"] == ack["branch"]
    assert landed["tree"]["sha"] == restore["tree"]
    assert [p["sha"] for p in landed["parents"]] == [restore["base"], restore["head"]]
    assert push["status"] == "green" and push["current_verified"] and push["artifact"]
    assert release["enforcement"] == "disabled" and str(release["id"]) == ack["hold"]
    assert load("red/trusted-verifier.json")["status"] == "hold"
    assert load("ordinary-after-restore/stale-verifier.json")["status"] == "hold"
    before = load("release/effective-before.json")
    after = load("release/effective-after.json")
    assert [rule for rule in before if rule["ruleset_id"] != release["id"]] == after
    assert load("release/ordinary-after-release.json")["head"]["sha"] == fresh["head"]
    assert load("release/ordinary-after-release.json")["mergeable"]
    return restore, old, fresh, landed, push, ack, after


restore, old, fresh, landed, push, ack, effective = native_target()
production_before = load("production-branch-before.json")["commit"]["sha"]
gate_final = load("production-final.json")
assert gate_final["rules_unchanged"] and gate_final["controls_unchanged"]
assert gate_final["before"] == production_before
rule_cases = {
    path.stem: {
        row["rule_type"]: row["result"]
        for row in json.loads(path.read_bytes())["rule_evaluations"]
    }
    for path in sorted((RECORDS / "rule-details").glob("*.json"))
}
assert all(
    rule_cases[n]["required_status_checks"] == "fail"
    for n in ("5136289087", "5136386588")
)
assert rule_cases["5136383866"]["required_status_checks"] == "pass"
assert rule_cases["5136383866"]["update"] == "fail"
assert rule_cases["5136523549"]["required_status_checks"] == "pass"
assert rule_cases["5136532518"]["required_status_checks"] == "fail"
merge_suite = load("rule-details/5136523549.json")
assert merge_suite["result"] == "bypass" and merge_suite["after_sha"] == landed["sha"]
contexts = next(
    row["parameters"]["required_status_checks"]
    for row in effective
    if row["type"] == "required_status_checks"
)
assert {row["context"] for row in contexts} == set(restore["jobs"])
assert {row["integration_id"] for row in contexts} == {15368}
scans = sorted(path for path in RECORDS.rglob("*") if path.is_file())
recipe = (
    "setup-lab.sh",
    "rollback-pilot.yml",
    "launch-case.sh",
    "dispatch-probe.sh",
    "switch-to-full.sh",
    "read-canonical.py",
    "complete-restore.sh",
    "refresh-restore.sh",
    "refresh-ordinary.sh",
    "verify-push.py",
    "release-hold.sh",
    "production-parity.py",
    "replay-lab-attestations.py",
    "pack-lab.py",
)
with ZipFile(ROOT / "rollback-evidence.zip", "w", compression=ZIP_DEFLATED) as archive:
    for path in [*scans, *(ROOT / name for name in recipe)]:
        name = path.relative_to(ROOT).as_posix()
        assert not any(
            part in {"private", ".git"} for part in path.relative_to(ROOT).parts
        )
        entry = ZipInfo(name)
        entry.compress_type = ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, path.read_bytes())
with ZipFile(ROOT / "rollback-evidence.zip") as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(scans) + len(
        recipe
    )

metrics_path = ROOT / "production/production-evidence.zip"
with ZipFile(metrics_path) as archive:
    metrics = json.loads(archive.read("replay/production-metrics.json"))

restore_job = next(
    j for j in load("restore/jobs.json")["jobs"] if j["name"] == "aitm-ci"
)
fresh_job = next(
    j for j in load("ordinary-fresh/jobs.json")["jobs"] if j["name"] == "aitm-ci"
)
times = {
    "restore_open_to_signed_seconds": seconds(
        restore_job["completed_at"], load("restore/pr-open.json")["created_at"]
    ),
    "restore_open_to_trusted_verifier_seconds": seconds(
        restore["verified_at"], load("restore/pr-open.json")["created_at"]
    ),
    "refresh_run_registration_to_signed_seconds": seconds(
        fresh_job["completed_at"], load("ordinary-fresh/run.json")["created_at"]
    ),
}
summary = {
    "issue": 337,
    "scope": "verified existing production PR baseline and disposable native rollback rehearsal",
    "production": {
        **gate_final,
        "prs": metrics["included_prs"],
        "archive_sha256": digest(metrics_path),
    },
    "lab": {
        "repository": restore["repository"],
        "seed": restore["base"],
        "restore": restore,
        "landed": landed["sha"],
        "push": push,
        "superseded_green": old,
        "superseded_restore": {
            "first_signed": load("restore-superseded/trusted-verifier.json"),
            "then_live_tested": load("restore-superseded/rebuilt-ref.json")["object"][
                "sha"
            ],
            "premerge_hold": load(
                "restore-superseded/premerge-hold/verify-premerge.json"
            ),
        },
        "reverified_ordinary": fresh,
        "acknowledgment": ack,
        "ordinary_mergeability_after_release": load(
            "release/ordinary-after-release.json"
        )["mergeable_state"],
        "effective_after_release": effective,
        "rules_at_probes": rule_cases,
        "timings": times,
    },
    "cutover_approved": False,
    "bounded_rollback_verified": True,
    "rollback_archive_sha256": digest(ROOT / "rollback-evidence.zip"),
}
(ROOT / "qualification-summary.json").write_text(
    json.dumps(summary, indent=2, sort_keys=True) + "\n"
)

print(
    f"""# #337 Full PR path and rollback results

The eight consecutive production PRs spent **22m 01s p50** and **45m 55s p95** from first canonical CI registration to final exact signed evidence. All eight exceeded fifteen minutes. The final successful attempt by itself took **8m 36s p95**. The whole PR took **54m 48s p95** from open to merge. Earlier heads, cancellations, reruns and review clocks are retained separately. Seven PRs retain historical exact verifier and review timestamps. [Production readout](production-readout.md) · [Production provider evidence](production-evidence.zip)

## Disposable rollback

The lab seeded the public protected production tree at `{production_before}`, added two rehearsal-only files and copied the native production trunk rule set. Its strictly app-bound required checks are an added lab control. The read-only trusted verifier authenticates exact candidate, all canonical jobs, coverage and signed artifact. An Actions status context by itself supplies no trusted attestation. This rehearsal uses fixed reviewed input paths and a simulated operator, with broader production credential and publisher isolation still to qualify.

| Held and restored behavior | Native evidence |
| --- | --- |
| Old app-authenticated pilot green, with zero canonical PR runs | [PR #1](https://github.com/kburson/aitm-rollback-337/pull/1) and [pilot run](https://github.com/kburson/aitm-rollback-337/actions/runs/43776122187) |
| Ordinary actor blocked while pilot check passed. After the gate switched, selected-only proof failed all six missing full contexts | Rule suites 5136279926 and 5136289087 |
| Intentional malformed JSON failed file checks and collector. Terminal signer skipped and both failing checks blocked merge | [Red run](https://github.com/kburson/aitm-rollback-337/actions/runs/43776314804) and suite 5136386588 |
| Operator direct push refused. Ordinary actor could not merge the fully green restore while the hold was active | Suites 5136384394 and 5136383866 |
| The independently reviewed forward restore changed only the disposable mode to full-only. Full evidence verified in {duration(times["restore_open_to_trusted_verifier_seconds"])} from PR open | [Restore PR](https://github.com/kburson/aitm-rollback-337/pull/2), [pre-merge review](restore-review.md) and native suite 5136523549 |
| Superseded exact full evidence refused after trunk advanced. Fresh ordinary head passed the full verifier on the restored base | Old [canonical run](https://github.com/kburson/aitm-rollback-337/actions/runs/{old["run_id"]}), suite 5136532518 and [new canonical run](https://github.com/kburson/aitm-rollback-337/actions/runs/{fresh["run_id"]}) |
| Restored trunk passed a fresh full push. A separate signed acknowledgment on newly reverified evidence released only the update hold | [Exact push](https://github.com/kburson/aitm-rollback-337/actions/runs/{push["run_id"]}); retained acknowledgment, native change and rule readback |

Ordinary native PR, deletion and non-fast-forward protections and all six app-bound canonical contexts remained active after release. The independent restore review was scoped to the exact head, tree and verifier receipt before the native merge. The supporting records show the recorded provider check identities, open candidate proof and exact landed parents. The refreshed ordinary PR remained open with all six required check contexts passing.

GitHub reported the ordinary PR mergeable with aggregate state `unstable`. The optional lab-only pilot job deliberately failed for the full-only route and was outside the six required checks. Only the reviewed restore PR merged during the rehearsal.

The first restore attempt passed full CI and independent review. The trusted pre-merge verifier refused it after GitHub regenerated the synthetic merge with the same parents and tree but a different SHA. The lab trunk stayed fixed. An empty synchronization commit preserved the intended tree, triggered fresh full CI and received a new exact disposition. The superseded attestation, rebuilt ref and failed pre-merge receipt are retained. The restore elapsed time above includes the refresh.

The reviewed evidence covers the existing full PR timing and one disposable rollback. The measured production cohort exceeds the latency target, and the experiment supplies no wider executable selection, production schedule cadence or cutover authorization. Production #103 control inputs, canonical workflow state and effective rules matched the starting snapshots. [Native rollback archive](rollback-evidence.zip) · [Machine readback](qualification-summary.json) · [Reproduction](reproduction.md)
""",
    end="",
)
