#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
kind=$1
base=$2
records="records/$kind"
mkdir "$records"
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$base"
git -C lab switch -c "probe/$kind" "$base"
case "$kind" in
  pilot)
    mkdir -p lab/docs
    printf '%s\n' '# Disposable pilot probe' > lab/docs/rollback-pilot-337.md
    git -C lab add docs/rollback-pilot-337.md
    ;;
  restore)
    printf '%s\n' '{"mode":"full-only","selected_path":"docs/rollback-pilot-337.md"}' > lab/.rollback-lab-mode.json
    git -C lab add .rollback-lab-mode.json
    ;;
  red)
    mkdir -p lab/docs
    printf '%s\n' '{"intentionally_invalid":' > lab/docs/rollback-red-337.json
    git -C lab add docs/rollback-red-337.json
    ;;
  ordinary)
    mkdir -p lab/docs
    printf '%s\n' '# Ordinary full-only restore probe' > lab/docs/rollback-ordinary-337.md
    git -C lab add docs/rollback-ordinary-337.md
    ;;
  *) exit 2 ;;
esac
git -C lab commit -qm "Rehearse the exact disposable $kind candidate"
git -C lab rev-parse HEAD > "$records/head"
printf '%s\n' "$base" > "$records/base"
git -C lab push -u origin "probe/$kind"
gh pr create -R "$repo" --base trunk --head "probe/$kind" --title "Disposable #337 $kind probe" \
  --body "Disposable exact #337 rollback experiment. Owner-authorized lab only." > "$records/pr-url"
number=$(sed 's|.*/||' "$records/pr-url")
gh api "repos/$repo/pulls/$number" > "$records/pr-open.json"
git -C lab switch --detach "$base"
cat "$records/pr-url"
