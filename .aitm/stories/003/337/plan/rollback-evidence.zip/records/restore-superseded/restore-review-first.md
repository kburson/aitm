# Independent review of the #337 disposable restore

Verdict: ACCEPTED

I accept the exact forward restore in [disposable PR #2](https://github.com/kburson/aitm-rollback-337/pull/2), repository ID `1459345121`, for the simulated operator's expected-head merge into `trunk` under the active update hold. This acceptance is limited to that candidate and recorded gate evidence. The reviewer exercised read-only provider and source checks in a separate session and used a clean detached checkout of the protected lab base to rerun the trusted verifier.

| Input | Exact identity |
| --- | --- |
| Literal base `trunk` | `0cc6c0c9fabe47efb36972d6aa0af0ec56f6bd15` |
| Candidate head `probe/restore` | `b0ee3b7abedaf897cfbd6330c853b0e2f9aecb50` |
| GitHub synthetic merge, ordered parents base then head | `37f507b7b4cf94d42eb0b20d169bc549207c1f15` |
| Reviewed tree | `6dcdc52b7dd0e582b0a5e555ea45af44dda65fa1` |
| Pinned production source | `4ba4354f603ad861c897111dcaaf2342fc68da86` |
| Reviewed rehearsal plan SHA-256 | `ccdca1f606d6142b472769eee74adc96a29b1926d1bbdab89fc34a45bf341a80` |

I compared the production pin, lab base and restore tree. The lab base adds `.github/workflows/rollback-pilot.yml` and `.rollback-lab-mode.json`. The restore changes only the latter's mode from `pilot` to `full-only`. The diff leaves the canonical workflow, trusted verifier, gate, observer, policy, lockfile, package configuration and test inputs byte-identical to the production pin. I authenticated the synthetic merge's ordered parents and compared its tree to the independently reviewed head tree. The public lab uses the repository's canonical `ci.yml`, workflow ID `419574482`.

The GitHub Actions run `43776307538` attempt `1` passed all six required jobs. The authenticated check IDs are `133003270801` for `python-base`, `133003270634` for `python`, `133003270798` for `quality`, `133003270850` for `file-checks`, `133005264639` for `collect-evidence` and `133005316531` for `aitm-ci`. The signed report records 1,486 baseline and 1,487 candidate tests, both line-coverage gates, and the exact installed-wheel evidence. My run of the delivered `tools/ci/verify_pr.py` with pinned `gh` 2.97.0 returned `pass` at `2026-11-15T23:51:26.454236+00:00`. Every field except the independently generated verification timestamp agrees with the author's retained verifier receipt. SHA-256 of `records/restore/trusted-verifier.json` is `59bffd48ff8b20782556daaa144f5bdbf28325c7e890d35f1c5f1af00ee25ca6`. Signed artifact `14186941252` has archive digest `sha256:045bfe6af5d86c12692f44578fa4665f80d0aa05d3d4cd409902367f86861a0d` and subject digest `0df8f9442dfd1922bef779409b3e3e01c5e59ba0397dd6b48a416780cc70c203`. [Exact run attempt](https://github.com/kburson/aitm-rollback-337/actions/runs/43776307538/attempts/1)

The copied normal trunk ruleset `27339225` matches the production rule parameters and grants zero bypasses. The separate strict full-check ruleset `27339233` requires all six check contexts from GitHub Actions app `15368`, with zero bypasses. The separate active update hold `27339262` grants only user `1082467` a PR-only bypass. The native app-bound contexts are one part of the rehearsal. The delivered trusted verifier binds the signed evidence to the current base, head, merge, tree, workflow, attempt and exact jobs, and remains mandatory. The simulation uses the administrative account as the designated operator. The production gate retains its existing authority. [Protection](https://github.com/kburson/aitm-rollback-337/rules/27339225) · [Required checks](https://github.com/kburson/aitm-rollback-337/rules/27339233) · [Update hold](https://github.com/kburson/aitm-rollback-337/rules/27339262)

This exact candidate disposition covers the restore source and premerge evidence. The rehearsal still requires its red denial, the held merge and verified landed tree, fresh exact restored-run and ordinary-candidate evidence, distinct simulated operator acknowledgment and release of only the hold.

Signed by the independent Codex reviewer `/root/review337`.
