#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
landed=$1
expected_run=$2
ordinary_head=$3
test "$landed" = "$(jq -r .sha records/restored/merged.json)"
test "$expected_run" = "$(jq -r .run_id records/restored/push/advisory.json)"
test "$ordinary_head" = "$(cat records/ordinary-after-restore/fresh-head)"
test "$(gh api user --jq .id)" = 1082467
out=records/release
mkdir "$out"
hold_id=$(jq -r .id records/hold-active.json)
gh api "repos/$repo/rulesets/$hold_id" > "$out/hold-before.json"
jq -e '.enforcement=="active"' "$out/hold-before.json" >/dev/null
gh api "repos/$repo/rules/branches/trunk" > "$out/effective-before.json"
diff <(jq -S . records/effective-with-hold-full.json) <(jq -S . "$out/effective-before.json")
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$landed"
python3 lab/tools/ci/verify_pr.py --repo "$repo" --pr 4 --target trunk --output "$PWD/$out/fresh-pr-verifier.json" \
  > "$out/fresh-pr-verifier.log" 2>&1
jq -e --arg base "$landed" --arg head "$ordinary_head" '.status=="pass" and .base==$base and .head==$head' "$out/fresh-pr-verifier.json" >/dev/null
diff <(jq -S 'del(.verified_at)' records/ordinary-fresh/trusted-verifier.json) <(jq -S 'del(.verified_at)' "$out/fresh-pr-verifier.json")
PYTHONDONTWRITEBYTECODE=1 python3 - "$landed" "$expected_run" "$out/fresh-push-advisory.json" <<'PY'
import json
from pathlib import Path
import sys
sys.path[:0]=[str(Path("lab/tools/ci").resolve())]
import ci_advisory as advisory
from verify_pr import GitHub
sha, run, destination=sys.argv[1:]
advisory.REPO="kburson/aitm-rollback-337"
provider=GitHub(advisory.REPO)
advisory.REPOSITORY_ID=provider.document("")["id"]
advisory.WORKFLOW_ID=provider.document("actions/workflows/ci.yml")["id"]
result=advisory.observe(provider,shadow=True)
assert result["status"]=="green" and result["current_verified"] and result["sha"]==sha and result["run_id"]==int(run)
Path(destination).write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
PY
diff <(jq -S . records/restored/push/advisory.json) <(jq -S . "$out/fresh-push-advisory.json")
mkdir -p private
test ! -e private/ack
ssh-keygen -q -t ed25519 -N '' -f private/ack
printf 'simulated-operator %s\n' "$(cut -d ' ' -f 1-2 private/ack.pub)" > "$out/allowed-signers"
jq -n --arg repo "$repo" --arg branch "$landed" --arg run "$expected_run" --arg ordinary "$ordinary_head" --arg hold "$hold_id" \
  --arg push_receipt "$(shasum -a 256 "$out/fresh-push-advisory.json" | cut -d ' ' -f 1)" \
  --arg pr_receipt "$(shasum -a 256 "$out/fresh-pr-verifier.json" | cut -d ' ' -f 1)" \
  --arg captured "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  '{schema:"aitm.disposable-rollback-acknowledgment/v1",actor_id:1082467,scope:"simulated operator",action:"release-only-disposable-hold",$repo,$hold,$branch,$run,$ordinary,$push_receipt,$pr_receipt,$captured}' \
  > "$out/acknowledgment.json"
ssh-keygen -Y sign -n aitm-337-ack -f private/ack "$out/acknowledgment.json"
ssh-keygen -Y verify -n aitm-337-ack -f "$out/allowed-signers" -I simulated-operator -s "$out/acknowledgment.json.sig" < "$out/acknowledgment.json" \
  > "$out/acknowledgment-verification.log"
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$landed"
jq '{name,target,bypass_actors,conditions,rules,enforcement:"disabled"}' "$out/hold-before.json" > "$out/release-request.json"
gh api --method PUT "repos/$repo/rulesets/$hold_id" --input "$out/release-request.json" > "$out/release-response.json"
jq -e --argjson id "$hold_id" '.id==$id and .enforcement=="disabled"' "$out/release-response.json" >/dev/null
gh api "repos/$repo/rules/branches/trunk" > "$out/effective-after.json"
diff <(jq -S --argjson id "$hold_id" '[.[]|select(.ruleset_id!=$id)]' "$out/effective-before.json") <(jq -S . "$out/effective-after.json")
gh api "repos/$repo/branches/trunk" > "$out/branch-after.json"
jq -e --arg landed "$landed" '.protected and .commit.sha==$landed' "$out/branch-after.json" >/dev/null
gh api "repos/$repo/pulls/4" > "$out/ordinary-after-release.json"
jq -e --arg landed "$landed" --arg head "$ordinary_head" '.base.sha==$landed and .head.sha==$head and .mergeable' "$out/ordinary-after-release.json"
