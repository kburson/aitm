#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
pilot_probe=$(jq -r .workflow_run_id records/probe-pilot-held/dispatch.json)
gh run view "$pilot_probe" -R "$repo" --log > records/probe-pilot-held/run.log
grep -E 'Cannot update this protected ref' records/probe-pilot-held/run.log
gh api "repos/$repo/actions/runs/$pilot_probe/attempts/1/jobs" > records/probe-pilot-held/jobs.json
gh api "repos/$repo/rulesets/rule-suites?per_page=100" > records/probe-pilot-held/rule-suites.json
id=$(jq -r .id records/pilot-rules.json)
contexts=$(jq -c '.pr_jobs + ["collect-evidence","aitm-ci"]' lab/tools/ci/policy.json)
jq --argjson contexts "$contexts" '{
  name,target,enforcement,bypass_actors,conditions,rules
} | .rules[0].parameters.required_status_checks=[$contexts[]|{context:.,integration_id:15368}]' \
   records/pilot-rules.json > records/full-rules-request.json
gh api --method PUT "repos/$repo/rulesets/$id" --input records/full-rules-request.json > records/full-rules.json
gh api "repos/$repo/rules/branches/trunk" > records/effective-with-hold-full.json
jq -e '[.[]|select(.type=="required_status_checks")|.parameters.required_status_checks|length] == [6]' \
   records/effective-with-hold-full.json > /dev/null
gh workflow enable ci.yml -R "$repo"
gh api "repos/$repo/actions/workflows/ci.yml" > records/canonical-enabled.json
jq -e '.state=="active"' records/canonical-enabled.json >/dev/null
test "$(gh api user --jq .id)" = 1082467
if gh api --include "repos/$repo/pulls/1/merge" --method PUT -f sha="$(cat records/pilot/head)" -f merge_method=merge \
    > records/pilot/operator-missing-full.log 2>&1; then
   echo 'Unexpectedly authorized the selected-only candidate'
   exit 1
fi
cat records/pilot/operator-missing-full.log
gh api "repos/$repo/rulesets/rule-suites?per_page=100" > records/pilot/missing-full-rule-suites.json
base=$(cat records/lab-base)
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$base"
./launch-case.sh restore "$base"
./launch-case.sh red "$base"
