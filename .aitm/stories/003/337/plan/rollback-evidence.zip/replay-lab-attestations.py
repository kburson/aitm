"""Verify retained lab commitments with the production evidence bundle's public root."""

import argparse
import json
import subprocess
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
REPO = "kburson/aitm-rollback-337"
CASES = ("restore-superseded", "restore", "ordinary", "ordinary-fresh")


def verify(case, trusted_root):
    folder = ROOT / "records" / case
    receipt = json.loads((folder / "trusted-verifier.json").read_bytes())
    assert receipt["status"] == "pass" and receipt["repository"] == REPO
    archive_path = folder / f"aitm-ci-evidence-a{receipt['run_attempt']}.zip"
    assert (
        receipt["archive_digest"]
        == "sha256:" + sha256(archive_path.read_bytes()).hexdigest()
    )
    with (
        ZipFile(archive_path) as archive,
        TemporaryDirectory(prefix="aitm-337-replay-") as scratch,
    ):
        assert sorted(archive.namelist()) == [
            "attestation.sigstore.json",
            "candidate.json",
        ]
        raw = archive.read("candidate.json")
        document = json.loads(raw)
        for key in ("pr", "base", "head", "tested", "tree"):
            assert document[key] == receipt[key]
        assert (document["run"], document["attempt"]) == (
            receipt["run_id"],
            receipt["run_attempt"],
        )
        assert sha256(raw).hexdigest() == receipt["subject_digest"]
        directory = Path(scratch)
        candidate = directory / "candidate.json"
        bundle = directory / "attestation.sigstore.json"
        candidate.write_bytes(raw)
        bundle.write_bytes(archive.read(bundle.name))
        subprocess.run(
            [
                "gh",
                "attestation",
                "verify",
                str(candidate),
                "--hostname",
                "github.com",
                "--repo",
                REPO,
                "--bundle",
                str(bundle),
                "--signer-workflow",
                f"{REPO}/.github/workflows/ci.yml",
                "--cert-oidc-issuer",
                "https://token.actions.githubusercontent.com",
                "--predicate-type",
                "https://slsa.dev/provenance/v1",
                "--source-ref",
                f"refs/pull/{receipt['pr']}/merge",
                "--source-digest",
                receipt["tested"],
                "--signer-digest",
                receipt["tested"],
                "--deny-self-hosted-runners",
                "--custom-trusted-root",
                str(trusted_root),
            ],
            check=True,
            capture_output=True,
        )
    print(
        case, receipt["run_id"], receipt["run_attempt"], receipt["tested"], "verified"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trust-root", required=True, type=Path)
    parser.add_argument("--case", action="append", choices=CASES)
    args = parser.parse_args()
    version = subprocess.check_output(["gh", "--version"], text=True).splitlines()[0]
    assert version.split()[:3] == ["gh", "version", "2.97.0"]
    for case in args.case or CASES:
        verify(case, args.trust_root.resolve())


if __name__ == "__main__":
    main()
