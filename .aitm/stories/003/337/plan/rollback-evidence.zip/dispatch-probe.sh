#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
stage=$1
pr=$2
base=$3
head=$4
out="records/probe-$stage"
mkdir "$out"
jq -n --arg pr "$pr" --arg base "$base" --arg head "$head" --arg stage "$stage" \
   '{ref:"trunk",inputs:{$pr,$base,$head,$stage}}' > "$out/request.json"
gh api -H 'X-GitHub-Api-Version: 2026-03-10' --method POST \
  "repos/$repo/actions/workflows/rollback-pilot.yml/dispatches" --input "$out/request.json" > "$out/dispatch.json"
jq -er '.workflow_run_id' "$out/dispatch.json"
