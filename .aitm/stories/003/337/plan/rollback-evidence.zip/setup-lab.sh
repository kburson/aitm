#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
root=$PWD
records=$root/records
lab=$root/lab
repo=kburson/aitm-rollback-337
git -C ../planning rev-parse origin/trunk > "$records/production-base"
base=$(cat "$records/production-base")
gh api repos/kburson/aitm/branches/trunk > "$records/production-branch-before.json"
test "$(jq -r .commit.sha "$records/production-branch-before.json")" = "$base"
jq -e '.protected' "$records/production-branch-before.json" > /dev/null
gh api repos/kburson/aitm/rules/branches/trunk > "$records/production-rules-before.json"
gh api repos/kburson/aitm/rulesets/26821811 > "$records/production-ruleset-before.json"
git clone --quiet --no-tags --reference-if-able "$root/../planning" --branch trunk --single-branch https://github.com/kburson/aitm.git "$lab"
test "$(git -C "$lab" rev-parse HEAD)" = "$base"
git -C "$lab" remote rename origin production
gh repo create "$repo" --public --description 'Disposable #337 production-path rollback rehearsal'
git -C "$lab" remote add origin "git@github.com:$repo.git"
printf '%s\n' '{"mode":"pilot","selected_path":"docs/rollback-pilot-337.md"}' > "$lab/.rollback-lab-mode.json"
cp rollback-pilot.yml "$lab/.github/workflows/rollback-pilot.yml"
git -C "$lab" add .rollback-lab-mode.json .github/workflows/rollback-pilot.yml
git -C "$lab" commit -qm 'Seed disposable rehearsal-only pilot beside the unchanged #103 controls'
git -C "$lab" rev-parse HEAD > "$records/lab-base"
git -C "$lab" push -u origin trunk
gh repo edit "$repo" --default-branch trunk --enable-merge-commit=true --enable-squash-merge=true --enable-rebase-merge=true
gh api "repos/$repo" > "$records/lab-repo.json"
jq '{name,target,enforcement,bypass_actors,conditions,rules}' "$records/production-ruleset-before.json" > "$records/normal-rules-request.json"
gh api --method POST "repos/$repo/rulesets" --input "$records/normal-rules-request.json" > "$records/normal-rules.json"
gh workflow disable ci.yml -R "$repo"
gh api "repos/$repo/actions/workflows/ci.yml" > "$records/canonical-disabled.json"
jq -e '.state=="disabled_manually"' "$records/canonical-disabled.json" > /dev/null
gh api "repos/$repo/branches/trunk" > "$records/lab-branch.json"
jq -e '.protected' "$records/lab-branch.json" > /dev/null
git -C "$lab" diff --name-only "$base" trunk
