#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
repo=kburson/aitm-rollback-337
restored=records/restored
mkdir "$restored"
receipt=records/restore/trusted-verifier.json
jq -e '.status=="pass" and .pr==2' "$receipt" >/dev/null
review_sha=$(shasum -a 256 "$receipt" | cut -d ' ' -f1)
head=$(jq -r .head "$receipt")
base=$(jq -r .base "$receipt")
tree=$(jq -r .tree "$receipt")
grep -F 'Verdict: ACCEPTED' restore-review.md
grep -F "$review_sha" restore-review.md
for value in "$head" "$base" "$tree"; do grep -F "$value" restore-review.md > /dev/null; done
test "$(gh api user --jq .id)" = 1082467
test "$(git -C lab rev-parse HEAD)" = "$base"
test "$(gh api "repos/$repo/branches/trunk" --jq .commit.sha)" = "$base"
test "$(gh api "repos/$repo/pulls/2" --jq .head.sha)" = "$head"
hold_id=$(jq -r .id records/hold-active.json)
gh api "repos/$repo/rulesets/$hold_id" > "$restored/hold-before.json"
jq -e '.enforcement=="active" and .bypass_actors[0].bypass_mode=="pull_request"' "$restored/hold-before.json" >/dev/null
python3 lab/tools/ci/verify_pr.py --repo "$repo" --pr 2 --target trunk --output "$PWD/$restored/verify-premerge.json" \
  > "$restored/verify-premerge.log" 2>&1
diff <(jq -S 'del(.verified_at)' "$receipt") <(jq -S 'del(.verified_at)' "$restored/verify-premerge.json")
gh api --method PUT "repos/$repo/pulls/2/merge" -f sha="$head" -f merge_method=merge > "$restored/merged.json"
jq -e '.merged' "$restored/merged.json" >/dev/null
landed=$(jq -r .sha "$restored/merged.json")
gh api "repos/$repo/git/commits/$landed" > "$restored/commit.json"
jq -e --arg base "$base" --arg head "$head" --arg tree "$tree" \
   '.tree.sha==$tree and [.parents[].sha]==[$base,$head]' "$restored/commit.json" >/dev/null
gh api "repos/$repo/branches/trunk" > "$restored/branch.json"
jq -e --arg landed "$landed" '.protected and .commit.sha==$landed' "$restored/branch.json" >/dev/null
gh api "repos/$repo/rules/branches/trunk" > "$restored/effective.json"
diff <(jq -S . records/effective-with-hold-full.json) <(jq -S . "$restored/effective.json")
gh api "repos/$repo/rulesets/rule-suites?per_page=100" > "$restored/rule-suites.json"
git -C lab fetch -q origin refs/heads/trunk:refs/remotes/origin/trunk
git -C lab switch --detach "$landed"
git -C lab show HEAD:.rollback-lab-mode.json | jq -e '.mode=="full-only"' >/dev/null
