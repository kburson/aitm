"""Retain exact native PR CI and run the unchanged trusted verifier."""

import json
import subprocess
import sys
from hashlib import sha256
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent
LAB = ROOT / "lab"
REPO = "kburson/aitm-rollback-337"
CONTEXTS = {
    "python-base",
    "python",
    "quality",
    "file-checks",
    "collect-evidence",
    "aitm-ci",
}


def provider(path, out=None):
    raw = subprocess.check_output(["gh", "api", f"repos/{REPO}/{path}"])
    if out is not None:
        out.write_bytes(raw)
    return json.loads(raw)


def git(*args):
    return subprocess.check_output(["git", "-C", str(LAB), *args], text=True).strip()


def main():
    name, pr_number, expected = sys.argv[1:4]
    assert expected in {"pass", "hold"}
    out = ROOT / "records" / name
    out.mkdir(exist_ok=True)
    pr = provider(f"pulls/{pr_number}", out / "pr-tested.json")
    head, base, tested = pr["head"]["sha"], pr["base"]["sha"], pr["merge_commit_sha"]
    assert pr["state"] == "open" and pr["base"]["ref"] == "trunk"
    assert (
        provider("branches/trunk", out / "target-before.json")["commit"]["sha"] == base
    )
    assert git("rev-parse", "HEAD") == base
    source_base = (ROOT / "records/production-base").read_text().strip()
    for path in (".github/workflows/ci.yml", "tools/ci/verify_pr.py"):
        assert git("rev-parse", f"{base}:{path}") == git(
            "rev-parse", f"{source_base}:{path}"
        )
    tested_commit = provider(f"git/commits/{tested}", out / "tested-commit.json")
    assert [p["sha"] for p in tested_commit["parents"]] == [base, head]
    tree = tested_commit["tree"]["sha"]
    workflow = provider("actions/workflows/ci.yml", out / "workflow.json")
    assert (
        workflow["path"] == ".github/workflows/ci.yml" and workflow["state"] == "active"
    )
    branch = quote(pr["head"]["ref"], safe="")
    rows = provider(
        f"actions/workflows/{workflow['id']}/runs?event=pull_request&branch={branch}&per_page=100",
        out / "run-list.json",
    )["workflow_runs"]
    (run,) = [row for row in rows if row["head_sha"] == head]
    assert run["status"] == "completed", run["status"]
    attempt = run["run_attempt"]
    route = f"actions/runs/{run['id']}"
    current = provider(route, out / "run.json")
    assert current["head_sha"] == head and current["run_attempt"] == attempt
    provider(f"{route}/attempts/{attempt}", out / "attempt.json")
    suite = provider(f"check-suites/{run['check_suite_id']}", out / "suite.json")
    assert suite["app"]["id"] == 15368 and suite["head_sha"] == head
    jobs = provider(f"{route}/attempts/{attempt}/jobs", out / "jobs.json")["jobs"]
    assert {j["name"] for j in jobs} == CONTEXTS
    for job in jobs:
        check = provider(f"check-runs/{job['id']}", out / f"check-{job['id']}.json")
        assert check["name"] == job["name"] and check["app"]["id"] == 15368
        assert check["head_sha"] == head and check["check_suite"]["id"] == suite["id"]
    artifacts = provider(f"{route}/artifacts?per_page=100", out / "artifacts.json")[
        "artifacts"
    ]
    for artifact in artifacts:
        raw = subprocess.check_output(
            ["gh", "api", f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip"]
        )
        assert len(raw) == artifact["size_in_bytes"]
        assert f"sha256:{sha256(raw).hexdigest()}" == artifact["digest"]
        assert artifact["workflow_run"]["id"] == run["id"]
        (out / f"{artifact['name']}.zip").write_bytes(raw)
    with (out / "actions.log").open("wb") as log:
        subprocess.run(
            [
                "gh",
                "run",
                "view",
                str(run["id"]),
                "-R",
                REPO,
                "--attempt",
                str(attempt),
                "--log",
            ],
            stdout=log,
            stderr=subprocess.STDOUT,
            check=True,
        )
    verifier_out = out / "trusted-verifier.json"
    with (out / "verifier.log").open("wb") as log:
        completed = subprocess.run(
            [
                sys.executable,
                str(LAB / "tools/ci/verify_pr.py"),
                "--repo",
                REPO,
                "--pr",
                pr_number,
                "--target",
                "trunk",
                "--output",
                str(verifier_out),
            ],
            cwd=LAB,
            stdout=log,
            stderr=subprocess.STDOUT,
            check=False,
        )
    result = json.loads(verifier_out.read_bytes())
    assert result["status"] == expected, result
    if expected == "pass":
        assert completed.returncode == 0
        assert (result["base"], result["head"], result["tested"], result["tree"]) == (
            base,
            head,
            tested,
            tree,
        )
        assert (result["run_id"], result["run_attempt"]) == (run["id"], attempt)
        assert set(result["jobs"]) == CONTEXTS
    else:
        assert completed.returncode != 0
    print(name, run["id"], attempt, result)


if __name__ == "__main__":
    main()
