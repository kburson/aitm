"""Replay the unchanged protected trunk reader with the lab provider identity."""

import json
import subprocess
import sys
from hashlib import sha256
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LAB = ROOT / "lab"
OUT = ROOT / "records/restored/push"
REPO = "kburson/aitm-rollback-337"
sys.path.insert(0, str(LAB / "tools/ci"))
import ci_advisory as advisory
from verify_pr import GitHub

OUT.mkdir(exist_ok=True)
git = ["git", "-C", str(LAB)]
sha = subprocess.check_output([*git, "rev-parse", "HEAD"], text=True).strip()
assert sha == json.loads((OUT.parent / "merged.json").read_bytes())["sha"]
api = GitHub(REPO)
advisory.REPO = REPO
advisory.REPOSITORY_ID = api.document("")["id"]
workflow = api.document("actions/workflows/ci.yml")
assert workflow["state"] == "active" and workflow["path"] == ".github/workflows/ci.yml"
advisory.WORKFLOW_ID = workflow["id"]
result = advisory.observe(api, shadow=True)
(OUT / "advisory.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
assert (
    result["sha"] == sha and result["status"] == "green" and result["current_verified"]
)
run, attempt = result["run_id"], result["attempt"]
route = f"actions/runs/{run}"
for path, name in (
    (route, "run.json"),
    (f"{route}/attempts/{attempt}/jobs", "jobs.json"),
    (f"{route}/artifacts", "artifacts.json"),
):
    (OUT / name).write_text(json.dumps(api.document(path), indent=2) + "\n")
data = result["artifact"]
raw = api.api(f"actions/artifacts/{data['id']}/zip")
assert data["digest"] == "sha256:" + sha256(raw).hexdigest()
(OUT / "python.zip").write_bytes(raw)
with (OUT / "actions.log").open("wb") as log:
    subprocess.run(
        ["gh", "run", "view", str(run), "-R", REPO, "--attempt", str(attempt), "--log"],
        stdout=log,
        stderr=subprocess.STDOUT,
        check=True,
    )
print("verified fresh restored push", run, attempt, sha)
