#!/usr/bin/env python3
"""Pin protected production source inputs and a public Sigstore trust root."""
from argparse import ArgumentParser
from pathlib import Path
from subprocess import check_output

from capture import RAW

ROLLOUT = "75d4bc06657f93f77d6b07e3ae2605cb1c9a269f"
SOURCES = (
    ".github/workflows/ci.yml",
    "tools/ci/verify_pr.py",
    "tools/ci/policy.json",
    "tools/ci/python_gate.py",
    "tools/ci/pytest_evidence.py",
    "packages/aitm-usage/uv.lock",
)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("code_checkout", type=Path)
    args = parser.parse_args()
    directory = RAW / "trusted"
    directory.mkdir(exist_ok=True)
    commit = args.code_checkout
    for source in SOURCES:
        data = check_output(["git", "-C", str(commit), "show", f"{ROLLOUT}:{source}"])
        (directory / Path(source).name).write_bytes(data)
    root = directory / "gh-trusted-root.jsonl"
    if not root.is_file():
        root.write_bytes(check_output(["gh", "attestation", "trusted-root"]))


if __name__ == "__main__":
    main()
