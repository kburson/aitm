#!/usr/bin/env python3
"""Replay the immutable portions of the canonical verifier on retained receipts."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha1, sha256
from pathlib import Path
from subprocess import check_output, run
from tempfile import TemporaryDirectory
import json
import sys
from urllib.parse import quote

from capture import RAW, REPO, ROOT, load, save_api

sys.path.insert(0, str(RAW / "trusted"))
import verify_pr as verifier

URL = f"https://github.com/{REPO}"
REPLAY = ROOT / "replay"


class HistoricalGitHub:
    repo = REPO
    url = URL

    def __init__(self, capture):
        self.capture = capture

    def read(self, path, file, *, binary=False):
        if self.capture:
            save_api(f"repos/{REPO}/{path}", file, binary=binary)
        return (RAW / file).read_bytes()

    def document(self, path):
        if path.startswith("actions/runs/"):
            _, _, run_id, route, *tail = path.split("/")
            if route.startswith("artifacts?"):
                file = f"run-{run_id}/artifacts.json"
            else:
                attempt, *job_route = tail
                file = f"run-{run_id}/attempt-{attempt}"
                file += "-jobs.json" if job_route else ".json"
        else:
            file = "historical-api/" + quote(path, safe="") + ".json"
        return verifier.decode_json(self.read(path, file))

    def pages(self, path, key):
        page = self.document(path)
        assert len(page[key]) == page["total_count"]
        return page[key]

    def api(self, path, *, limit):
        _, _, artifact_id, download = path.split("/")
        assert download == "zip"
        artifacts = tuple(RAW.glob(f"run-*/artifact-{artifact_id}.zip"))
        assert len(artifacts) == 1 and artifacts[0].stat().st_size <= limit
        return artifacts[0].read_bytes()

    def attestation(self, subject, bundle, ref, merge):
        with TemporaryDirectory() as directory:
            candidate = Path(directory) / "candidate.json"
            attestation = candidate.with_name("attestation.sigstore.json")
            candidate.write_bytes(subject)
            attestation.write_bytes(bundle)
            output = run(
                [
                    "gh", "attestation", "verify", str(candidate), "--hostname", "github.com",
                    "--repo", self.repo, "--bundle", str(attestation), "--signer-workflow",
                    f"{self.repo}/{verifier.WORKFLOW}", "--cert-oidc-issuer", verifier.ISSUER,
                    "--predicate-type", verifier.PREDICATE, "--source-ref", ref,
                    "--source-digest", merge, "--signer-digest", merge, "--deny-self-hosted-runners",
                    "--custom-trusted-root", str(RAW / "trusted/gh-trusted-root.jsonl"),
                    "--format", "json",
                ],
                capture_output=True, check=True,
            )
        return verifier.decode_json(output.stdout)


def reports():
    for directory in sorted(RAW.glob("run-*")):
        for archive in sorted(directory.glob("artifact-*.zip")):
            raw = archive.read_bytes()
            subject, bundle = verifier.read_evidence_archive(raw)
            report = verifier.decode_json(subject)
            yield directory, archive, report, subject, bundle


def historical_validation(entry, live_runs, reviewed, capture):
    directory, archive, report, subject, bundle = entry
    run_id, attempt, pr_id = (report[k] for k in ("run", "attempt", "pr"))
    attempt_path = f"actions/runs/{run_id}/attempts/{attempt}"
    native = load(f"{directory.name}/attempt-{attempt}.json")
    latest = live_runs[run_id]
    pr = load(f"pr-{pr_id}.json")
    provider = HistoricalGitHub(capture)
    repository_id = pr["base"]["repo"]["id"]
    pull = verifier.Pull(pr_id, repository_id, pr["base"]["ref"], pr["head"]["ref"],
                         report["base"], report["head"], report["tested"])
    verifier.run_identity(native, pull, latest["workflow_id"])
    assert native["head_branch"] == pull.head_branch
    assert native["id"] == run_id and native["run_attempt"] == attempt
    assert native["check_suite_id"] == latest["check_suite_id"]
    assert native["path"] == ".github/workflows/ci.yml"
    assert verifier.successful(native)
    started = verifier.timestamp(native["run_started_at"])
    if native["pull_requests"]:
        assert verifier.matches_pull(native, pull)
    artifact, replay_subject, replay_bundle = verifier.attempt_archive(provider, pull, native)
    assert artifact["id"] == int(archive.stem.removeprefix("artifact-"))
    assert (replay_subject, replay_bundle) == (subject, bundle)
    invocation, subject_digest = verifier.verify_certificate(provider, pull, native, started, subject, bundle)
    commit = verifier.commit(provider, pull.merge)
    assert [parent["sha"] for parent in commit["parents"]] == [pull.base, pull.head]
    assert commit["tree"]["sha"] == report["tree"]
    final_head = pr["head"]["sha"] == pull.head
    evidence = {
        "pr": pr_id, "run": run_id, "attempt": attempt, "attempt_started_at": native["run_started_at"],
        "base_sha": pull.base, "head_sha": pull.head, "synthetic_sha": pull.merge,
        "tree": report["tree"], "artifact_id": artifact["id"],
        "artifact_created_at": artifact["created_at"], "archive_sha256": artifact["digest"],
        "subject_sha256": subject_digest, "invocation": invocation,
        "final_head": final_head,
        "signature_verified": True,
        "provider_pr_associations_at_readback": native["pull_requests"],
    }
    if final_head:
        landed = load(f"pr-{pr_id}/landed-commit.json")
        assert pr["merge_commit_sha"] == landed["sha"] and landed["tree"]["sha"] == report["tree"]
        assert [parent["sha"] for parent in landed["parents"]] == [pull.base, pull.head]
        assert latest["run_attempt"] == attempt
        suite = provider.document(f"check-suites/{native['check_suite_id']}")
        assert suite["id"] == native["check_suite_id"] and suite["head_sha"] == pull.head
        assert suite["app"]["slug"] == "github-actions" and verifier.successful(suite)
        reviewed_tree = reviewed.get(pr_id, {}).get("reviewed_tree")
        policy, controls, base_identity = verifier.verify_controls(provider, pull, report["tree"], reviewed_tree)
        expected_control_blobs = {}
        for key, source in (verifier.CONTROLS | {"verifier": verifier.VERIFIER}).items():
            data = (RAW / "trusted" / Path(source).name).read_bytes()
            expected_control_blobs[key] = sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
        assert controls == expected_control_blobs
        jobs = verifier.verify_jobs(provider, pull, native, attempt_path, started, suite,
                                    set(policy["pr_jobs"]) | verifier.FIXED_JOBS)
        coverage = verifier.report_evidence(subject, pull, native, report["tree"], policy, controls, base_identity)
        evidence.update({
            "landed_sha": landed["sha"], "job_ids": jobs, "coverage": coverage,
            "immutable_canonical_checks_replayed": True, "reviewed_tree_used": reviewed_tree,
        })
        if pr_id in reviewed:
            last = reviewed[pr_id]
            for key, value in {
                "repository": REPO, "repository_id": repository_id, "target": pull.target,
                "run_id": run_id, "run_attempt": attempt, "base": pull.base, "head": pull.head,
                "tested": pull.merge, "tree": report["tree"], "artifact_id": artifact["id"],
                "archive_digest": artifact["digest"], "subject_digest": subject_digest, "jobs": jobs,
                "coverage": coverage, "controls": controls, "workflow_id": native["workflow_id"],
            }.items():
                assert last[key] == value, (pr_id, key, last.get(key), value)
            evidence["historical_verifier_at"] = last["verified_at"]
    return evidence


def planning_verifier_receipts():
    native_heads = [load(path.name) for path in RAW.glob("pr-*.json") if path.name != "pr-319.json"]
    heads = {pr["number"]: pr["head"]["sha"] for pr in native_heads}
    recorded = {}
    for file in sorted((RAW / "planning").glob("*/*/plan/*signed-hosted*.json")):
        receipt = verifier.decode_json(file.read_bytes())
        pr = receipt.get("pr")
        if pr not in heads or receipt.get("status") != "pass" or receipt.get("head") != heads[pr]:
            continue
        if pr in recorded:
            assert recorded[pr]["verified_at"] == receipt["verified_at"]
        recorded[pr] = receipt
    return recorded


def write_output(path, payload):
    path.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n")


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true", help="read the supplementary immutable records from GitHub")
    args = parser.parse_args()
    REPLAY.mkdir(exist_ok=True)
    gh_version = check_output(["gh", "--version"], text=True).splitlines()[0]
    assert gh_version.split()[:3] == ["gh", "version", verifier.GH_VERSION]
    assert sha256((RAW / "trusted/ci.yml").read_bytes()).hexdigest() == "868d81ddcf374da2a98741bbee2a2ac0495da8041945af12b11bb85078d93e18"
    live = {run["id"]: run for run in load("ci-runs-page-1.json")["workflow_runs"]}
    reviewed = planning_verifier_receipts()
    with ThreadPoolExecutor(max_workers=6) as executor:
        pending = [executor.submit(historical_validation, entry, live, reviewed, args.capture)
                   for entry in reports()]
        rows = [task.result() for task in pending]
    assert len(rows) == 15 and len({row["pr"] for row in rows if row["final_head"]}) == 8
    write_output(REPLAY / "historical-validation.json", rows)
    print(f"Signature and historical identity verified for {len(rows)} artifacts. "
          f"Immutable canonical checks replayed for {sum(row['final_head'] for row in rows)} final candidates. "
          f"Retained pre-merge verifier timestamps: {sum('historical_verifier_at' in row for row in rows)}.")


if __name__ == "__main__":
    main()
