#!/usr/bin/env python3
"""Create a deterministic production evidence ZIP with per-file SHA-256."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "production-evidence.zip"
MANIFEST = ROOT / "SHA256SUMS"
ENTRY_DATE = (2026, 11, 15, 23, 35, 0)
SOURCE_FILES = (
    "archive.py", "capture.py", "capture-planning.py", "capture-trusted.py",
    "cohort.json", "historical.py", "measure.py", "production-readout.md",
)


def main():
    sources = [ROOT / name for name in SOURCE_FILES]
    sources.extend(
        file for directory in ("raw", "replay") for file in (ROOT / directory).rglob("*")
        if file.is_file() and "__pycache__" not in file.parts and not file.name.startswith(".")
    )
    sources.sort()
    MANIFEST.write_text("".join(
        f"{sha256(file.read_bytes()).hexdigest()}  {file.relative_to(ROOT)}\n"
        for file in sources
    ))
    with ZipFile(ARCHIVE, mode="w") as archive:
        for file in sorted([*sources, MANIFEST]):
            entry = ZipInfo(str(file.relative_to(ROOT)), ENTRY_DATE)
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, file.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
    digest = sha256(ARCHIVE.read_bytes()).hexdigest()
    ARCHIVE.with_suffix(".zip.sha256").write_text(f"{digest}  {ARCHIVE.name}\n")
    print(f"{len(sources)} files, {ARCHIVE.stat().st_size} bytes, SHA-256 {digest}")


if __name__ == "__main__":
    main()
