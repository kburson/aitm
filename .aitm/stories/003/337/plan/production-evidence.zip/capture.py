#!/usr/bin/env python3
"""Read-only GitHub Actions and pull-request evidence capture."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run
from tempfile import NamedTemporaryFile
import json
from urllib.parse import urlencode

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw"
CONFIG = json.loads((ROOT / "cohort.json").read_text())
REPO = CONFIG["repository"]
START = CONFIG["after_rollout_merge_utc_exclusive"]
END = CONFIG["cutoff_utc_inclusive"]


def save_api(path, destination, *, binary=False):
    output = RAW / destination
    output.parent.mkdir(exist_ok=True, parents=True)
    if output.is_file() and output.stat().st_size and not binary:
        json.loads(output.read_bytes())
        return
    if output.is_file() and output.stat().st_size:
        return
    response = run(["gh", "api", path], capture_output=True, check=False)
    if response.returncode:
        output.with_name(output.name + ".error.txt").write_bytes(response.stderr)
        raise RuntimeError(f"{path}: {response.stderr.decode()}")
    if not binary:
        json.loads(response.stdout)
    with NamedTemporaryFile(dir=output.parent, delete=False) as staged:
        staged.write(response.stdout)
    Path(staged.name).replace(output)


def load(relative):
    return json.loads((RAW / relative).read_bytes())


def capture_pr(number):
    target = f"repos/{REPO}/pulls/{number}"
    save_api(target, f"pr-{number}.json")
    save_api(target + "/reviews?per_page=100", f"pr-{number}/native-reviews.json")
    save_api(target + "/commits?per_page=100", f"pr-{number}/commits.json")
    save_api(f"repos/{REPO}/issues/{number}/timeline?per_page=100", f"pr-{number}/timeline.json")
    save_api(f"repos/{REPO}/git/commits/{load(f'pr-{number}.json')['merge_commit_sha']}",
             f"pr-{number}/landed-commit.json")


def capture_run(workflow):
    run_id = workflow["id"]
    target = f"repos/{REPO}/actions/runs/{run_id}"
    for attempt in range(1, workflow["run_attempt"] + 1):
        save_api(f"{target}/attempts/{attempt}", f"run-{run_id}/attempt-{attempt}.json")
        save_api(f"{target}/attempts/{attempt}/jobs?per_page=100",
                 f"run-{run_id}/attempt-{attempt}-jobs.json")
    save_api(f"{target}/artifacts?per_page=100", f"run-{run_id}/artifacts.json")
    artifacts = load(f"run-{run_id}/artifacts.json")
    assert artifacts["total_count"] == len(artifacts["artifacts"])
    for artifact in artifacts["artifacts"]:
        if artifact["name"].startswith("aitm-ci-evidence-a") and not artifact["expired"]:
            artifact_id = artifact["id"]
            save_api(f"repos/{REPO}/actions/artifacts/{artifact_id}/zip",
                     f"run-{run_id}/artifact-{artifact_id}.zip", binary=True)


def main():
    save_api(f"repos/{REPO}/pulls?state=all&sort=created&direction=desc&per_page=100",
             "pulls-page-1.json")
    save_api(f"repos/{REPO}/pulls/{CONFIG['rollout_pr']}", "pr-319.json")
    assert load("pr-319.json")["merged_at"] == START
    query = urlencode({"event": "pull_request", "created": f"{START}..{END}", "per_page": 100})
    save_api(f"repos/{REPO}/actions/workflows/ci.yml/runs?{query}", "ci-runs-page-1.json")
    pull_page = load("pulls-page-1.json")
    assert pull_page[-1]["created_at"] < START
    cohort = [
        pull for pull in pull_page
        if START < pull["created_at"] <= END and pull["merged_at"] and pull["merged_at"] <= END
        and pull["base"]["ref"] == CONFIG["base"] and pull["head"]["repo"]["full_name"] == REPO
    ]
    workflow_page = load("ci-runs-page-1.json")
    native_runs = workflow_page["workflow_runs"]
    assert workflow_page["total_count"] == len(native_runs)
    branches = {pull["head"]["ref"]: pull for pull in cohort}
    assert len(branches) == len(cohort)
    relevant_runs = [
        workflow for workflow in native_runs
        if {item["number"] for item in workflow["pull_requests"]} & {pull["number"] for pull in cohort}
        or (workflow["head_branch"] in branches
            and workflow["head_repository"]["full_name"] == REPO
            and branches[workflow["head_branch"]]["created_at"] <= workflow["created_at"]
            <= branches[workflow["head_branch"]]["merged_at"])
    ]
    with ThreadPoolExecutor(max_workers=6) as executor:
        pending = [executor.submit(capture_pr, pull["number"]) for pull in cohort]
        pending.extend(executor.submit(capture_run, workflow) for workflow in relevant_runs)
        for task in pending:
            task.result()
    save_api(f"repos/{REPO}/rules/branches/{CONFIG['base']}", "trusted/active-trunk-rules.json")
    save_api(f"repos/{REPO}/git/ref/heads/{CONFIG['base']}", "trusted/trunk-ref.json")
    save_api(f"repos/{REPO}/actions/workflows/ci.yml", "trusted/canonical-workflow.json")
    save_api(f"repos/{REPO}/pulls/324/files?per_page=100", "pr-324/files.json")
    print(f"Retained {len(cohort)} PRs and {len(relevant_runs)} canonical workflow runs.")


if __name__ == "__main__":
    main()
