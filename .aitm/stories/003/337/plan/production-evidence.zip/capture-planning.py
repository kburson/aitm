#!/usr/bin/env python3
"""Export exact protected planning receipts without modifying its checkout."""
import argparse
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REVISION = "6d1f04145dbf60771c1dc476c484d8bde94c3335"
STORIES = (120, 122, 325, 326, 329, 330, 331)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("planning", type=Path)
    args = parser.parse_args()
    git = ("git", "-C", str(args.planning))
    for story in STORIES:
        directory = f".aitm/stories/{story // 100:03}/{story}"
        names = subprocess.check_output(
            (*git, "ls-tree", "-r", "--name-only", REVISION, "--", directory), text=True
        ).splitlines()
        for name in names:
            if not re.search(
                r"/events\.jsonl$|signed-hosted.*\.json$|independent-source.*\.(json|md)$|verified-delivery\.json$",
                name,
            ):
                continue
            target = ROOT / "raw/planning" / name.removeprefix(".aitm/stories/")
            target.parent.mkdir(exist_ok=True, parents=True)
            target.write_bytes(subprocess.check_output((*git, "show", f"{REVISION}:{name}")))
    git_info = subprocess.check_output(
        (*git, "show", "--no-patch", "--format=fuller", REVISION), text=True
    )
    (ROOT / "raw/planning/revision.txt").write_text(git_info)


if __name__ == "__main__":
    main()
