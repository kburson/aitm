#!/usr/bin/env python3
"""Compute the locked production PR cohort clocks from retained data."""
from datetime import datetime
from hashlib import sha256
from itertools import combinations
from math import ceil
import json
from zipfile import ZipFile

from capture import CONFIG, END, RAW, REPO, ROOT, START, load

REPLAY = ROOT / "replay"
LANES = ("python-base", "python", "quality", "file-checks", "collect-evidence", "aitm-ci")
STEPS = {
    "base_inventory": ("python-base", "Run isolated trusted base inventory and outcomes"),
    "base_setup_job": ("python-base", "Set up job"),
    "candidate_qualify_inputs": ("python", "Qualify and record exact candidate inputs"),
    "candidate_tests_and_coverage": ("python", "Run parallel behavior suite and retain exact coverage"),
    "wheel_build_and_installed_smoke": ("python", "Build and smoke-test the exact installed wheel"),
    "quality_lint_and_format": ("quality", "Lint and format checks"),
    "tracked_file_checks": ("file-checks", "Check tracked Markdown, YAML and JSON"),
    "collector_evaluate": ("collect-evidence", "Evaluate required evidence and assemble the candidate"),
    "sigstore_attestation_step": ("aitm-ci", "Run actions/attest@"),
}


def read_json(file):
    return json.loads(file.read_bytes())


def timedelta_seconds(start, end):
    if start is None or end is None:
        return None
    return round((datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds(), 3)


def interval(start, end):
    value = timedelta_seconds(start, end)
    assert value is None or value >= 0, (start, end, value)
    return value


def step_seconds(jobs, job, name):
    matching = [step for step in jobs[job]["steps"] if step["name"].startswith(name)]
    assert len(matching) == 1 and matching[0]["conclusion"] == "success", (job, name)
    return interval(matching[0]["started_at"], matching[0]["completed_at"])


def eligible_pulls():
    pulls = load("pulls-page-1.json")
    eligibles = []
    excluded = []
    for pull in pulls:
        opened = pull["created_at"]
        merged = pull["merged_at"]
        if not (START <= opened <= END or merged is not None and START <= merged <= END):
            continue
        if opened <= START:
            reason = "opened before the canonical workflow rollout completed"
        elif merged is None:
            reason = "no merged_at at observation readback"
        elif merged > END:
            reason = "merged after cutoff"
        elif pull["base"]["ref"] != CONFIG["base"]:
            reason = "literal base is outside cohort"
        elif pull["head"]["repo"]["full_name"] != REPO:
            reason = "head repository is outside canonical CI scope"
        else:
            eligibles.append(pull)
            continue
        excluded.append({"pr": pull["number"], "reason": reason, "opened": opened, "merged": merged})
    return sorted(eligibles, key=lambda p: p["created_at"]), excluded


def attempts_for(pull, workflow_runs, verified):
    pr_number = pull["number"]
    timeline = load(f"pr-{pr_number}/timeline.json")
    commits = {node["sha"] for node in load(f"pr-{pr_number}/commits.json")}
    commits.update(node["sha"] for node in timeline if node["event"] == "committed")
    rows = []
    for run in workflow_runs:
        if not (pull["created_at"] <= run["created_at"] <= pull["merged_at"]):
            continue
        if run["head_branch"] != pull["head"]["ref"] or run["head_repository"]["full_name"] != REPO:
            continue
        for attempt in range(1, run["run_attempt"] + 1):
            native = load(f"run-{run['id']}/attempt-{attempt}.json")
            job_data = load(f"run-{run['id']}/attempt-{attempt}-jobs.json")
            assert job_data["total_count"] == len(job_data["jobs"])
            jobs = {job["name"]: job for job in job_data["jobs"]}
            assert len(jobs) == len(job_data["jobs"])
            proof = verified.get((run["id"], attempt))
            if proof:
                assert proof["pr"] == pr_number and proof["head_sha"] == native["head_sha"]
                association = "verified signed candidate and certificate, head branch and run window"
            elif any(item["number"] == pr_number for item in native["pull_requests"]):
                association = "native attempt PR association"
            elif native["head_sha"] in commits:
                association = "native PR commit, unique matching head branch and run window"
            else:
                association = "unique matching head branch and run window only"
            signer = jobs.get("aitm-ci", {})
            rows.append({
                "run": run["id"], "attempt": attempt, "outcome": native["conclusion"],
                "run_registered_at": run["created_at"], "attempt_record_created_at": native["created_at"],
                "attempt_started_at": native["run_started_at"], "attempt_updated_at": native["updated_at"],
                "head_sha": native["head_sha"], "head_is_landed": native["head_sha"] == pull["head"]["sha"],
                "base_sha_from_signed_report": proof["base_sha"] if proof else None,
                "synthetic_sha_from_signed_report": proof["synthetic_sha"] if proof else None,
                "native_green_signer_at": signer["completed_at"] if signer.get("conclusion") == "success" else None,
                "attested_artifact": proof,
                "pr_association": association,
                "job_outcomes": {job: record["conclusion"] for job, record in sorted(jobs.items())},
            })
    return sorted(rows, key=lambda item: (item["attempt_started_at"], item["run"], item["attempt"]))


def planning_review(pr_number, proof):
    for delivered in sorted((RAW / "planning").glob("*/*/plan/*verified-delivery.json")):
        record = read_json(delivered)
        if record["number"] != pr_number:
            continue
        assert record["headRefOid"] == proof["head_sha"]
        assert record["literalBase"] == proof["base_sha"]
        assert record["deliveredTree"] == proof["tree"]
        assert record["mergeCommit"]["oid"] == proof["landed_sha"]
        story_folder = delivered.parent.parent
        events = [json.loads(line) for line in (story_folder / "events.jsonl").read_text().splitlines()]
        findings = []
        for receipt in sorted(delivered.parent.glob("*independent-source*receipt.json")):
            review = read_json(receipt)
            if review["head"] != proof["head_sha"] or review["verdict"] != "PASS":
                continue
            assert review["base"] == proof["base_sha"] and review["tree"] == proof["tree"]
            assert review["run_id"] == proof["run"] and review["run"] == proof["invocation"]
            expected = f"plan/{receipt.name}"
            for event in events:
                data = event["data"]
                if data.get("path") == expected and data.get("kind") == "independent-source-review":
                    assert data["sha256"] == sha256(receipt.read_bytes()).hexdigest()
                    basis = "planning evidence-recorded timestamp; exact review receipt hash matches"
                elif data.get("state") == "review" and expected in data.get("evidence", []):
                    basis = "planning Review entry time explicitly referencing exact review receipt"
                else:
                    continue
                findings.append({
                    "timestamp": event["ts"], "clock": basis, "story": review["story"],
                    "reviewer": review["reviewer"], "effort": review["effort"],
                    "receipt_path": str(receipt.relative_to(RAW)),
                })
        assert len(findings) == 1, (pr_number, findings)
        return findings[0]
    return None


def assess_pull(pull, runs, verified):
    pr_id = pull["number"]
    first_open = pull["created_at"]
    merged = pull["merged_at"]
    attempts = attempts_for(pull, runs, verified)
    first = min(attempts, key=lambda record: record["run_registered_at"])
    first_trigger = first["run_registered_at"]
    initial = load(f"run-{first['run']}/attempt-1-jobs.json")["jobs"]
    first_runner = min(job["started_at"] for job in initial if job.get("runner_id"))
    final_proof, = (node["attested_artifact"] for node in attempts
                    if node["head_is_landed"] and node["attested_artifact"])
    final = next(node for node in attempts if (node["run"], node["attempt"]) ==
                 (final_proof["run"], final_proof["attempt"]))
    final_signer = final["native_green_signer_at"]
    final_avail = max(final_proof["artifact_created_at"], final_signer)
    assert datetime.fromisoformat(final_avail) <= datetime.fromisoformat(merged)
    first_green = min((node["native_green_signer_at"] for node in attempts
                       if node["native_green_signer_at"]), default=None)
    first_signed_artifact = min(node["attested_artifact"]["artifact_created_at"]
                                for node in attempts if node["attested_artifact"])
    jobs = {
        job["name"]: job for job in
        load(f"run-{final['run']}/attempt-{final['attempt']}-jobs.json")["jobs"]
    }
    lanes = {}
    for lane in LANES:
        job = jobs[lane]
        lanes[lane] = {
            "queue_seconds": interval(job["created_at"], job["started_at"]),
            "run_seconds": interval(job["started_at"], job["completed_at"]),
            "created_at": job["created_at"], "started_at": job["started_at"],
            "completed_at": job["completed_at"],
        }
    assert load(f"pr-{pr_id}/native-reviews.json") == []
    recorded_review = planning_review(pr_id, final_proof)
    reviewed_at = recorded_review["timestamp"] if recorded_review else None
    verifier_at = final_proof.get("historical_verifier_at")
    decision = max((verifier_at, reviewed_at), key=datetime.fromisoformat) if verifier_at and reviewed_at else None
    signed = {lane: lanes[lane]["completed_at"] for lane in LANES}
    first_final_run = min(item["run_registered_at"] for item in attempts if item["head_is_landed"])
    elapsed = {
        "open_to_first_registration": interval(first_open, first_trigger),
        "first_registration_to_first_runner": interval(first_trigger, first_runner),
        "open_to_first_native_green_any_head": interval(first_open, first_green),
        "open_to_first_retained_signed_upload_any_head": interval(first_open, first_signed_artifact),
        "open_to_final_registration": interval(first_open, first_final_run),
        "final_registration_to_final_attempt_start": interval(first_final_run, final["attempt_started_at"]),
        "final_attempt_start_to_signed_job_complete": interval(final["attempt_started_at"], final_signer),
        "final_registration_to_signed_job_complete": interval(first_final_run, final_signer),
        "open_to_final_signed_upload": interval(first_open, final_proof["artifact_created_at"]),
        "open_to_final_signed_job_complete": interval(first_open, final_signer),
        "first_registration_to_final_signed_job_complete": interval(first_trigger, final_signer),
        "signed_upload_to_job_complete": interval(final_proof["artifact_created_at"], final_signer),
        "dependencies_done_to_collector_start": interval(max(signed[name] for name in LANES[:4]),
                                                         jobs["collect-evidence"]["started_at"]),
        "collector_done_to_signer_start": interval(signed["collect-evidence"], jobs["aitm-ci"]["started_at"]),
        "signed_available_to_historical_verifier": interval(final_avail, verifier_at),
        "open_to_historical_verifier": interval(first_open, verifier_at),
        "first_registration_to_historical_verifier": interval(first_trigger, verifier_at),
        "open_to_exact_review_recorded": interval(first_open, reviewed_at),
        "first_registration_to_verifier_and_review_recorded": interval(first_trigger, decision),
        "recorded_verifier_and_review_to_merge": interval(decision, merged),
        "open_to_merge": interval(first_open, merged),
    }
    archive_file, = RAW.glob(f"run-{final['run']}/artifact-{final_proof['artifact_id']}.zip")
    with ZipFile(archive_file) as archive:
        candidate = json.loads(archive.read("candidate.json"))
    return {
        "pr": pr_id, "url": pull["html_url"], "title": pull["title"],
        "opened_at": first_open, "merged_at": merged, "first_registration_at": first_trigger,
        "final_registration_at": first_final_run, "first_runner_at": first_runner,
        "final": final, "attempts": attempts, "source_review": recorded_review,
        "additional_recorded_attempts": len(attempts) - 1,
        "elapsed_seconds": elapsed, "lanes": lanes,
        "step_seconds": {code: step_seconds(jobs, job, name) for code, (job, name) in STEPS.items()},
        "signed_timings": candidate["timings"],
        "tests": candidate["result"]["tests"], "baseline_tests": candidate["result"]["baseline_tests"],
        "coverage": candidate["result"]["coverage"], "control_blob_ids": candidate["controls"],
    }


def stats(samples, applicable):
    known = sorted(value for value in samples if value is not None)
    size = len(known)
    q = lambda p: known[ceil(p * size) - 1] if size else None
    return {
        "n": size, "missing": applicable - size, "min": known[0] if known else None, "p50": q(0.5), "p95": q(0.95),
        "max": known[-1] if known else None,
        "at_or_above_600": sum(value >= 600 for value in known),
        "at_or_above_900": sum(value >= 900 for value in known),
    }


def main():
    pulls, excluded = eligible_pulls()
    runs = load("ci-runs-page-1.json")["workflow_runs"]
    proofs = read_json(REPLAY / "historical-validation.json")
    assert len({(item["run"], item["attempt"]) for item in proofs}) == len(proofs)
    verified = {(item["run"], item["attempt"]): item for item in proofs}
    rows = [assess_pull(pull, runs, verified) for pull in pulls]
    count = len(rows)
    summary = {
        "clocks": {metric: stats((row["elapsed_seconds"][metric] for row in rows), count)
                   for metric in rows[0]["elapsed_seconds"]},
        "lanes": {
            lane: {metric: stats((row["lanes"][lane][metric] for row in rows), count)
                   for metric in ("queue_seconds", "run_seconds")}
            for lane in LANES
        },
        "steps": {step: stats((row["step_seconds"][step] for row in rows), count) for step in STEPS},
        "signed_report": {metric: stats((row["signed_timings"][metric] for row in rows), count)
                          for metric in ("setup", "test", "total", "hosted_seconds", "queue")},
    }
    intervals = []
    for a, b in combinations(rows, 2):
        start = max(a["opened_at"], b["opened_at"])
        end = min(a["merged_at"], b["merged_at"])
        if start < end:
            intervals.append({"prs": [a["pr"], b["pr"]], "open_overlap_seconds": interval(start, end)})
    considered = {record["run"] for row in rows for record in row["attempts"]}
    report = {
        "cohort": CONFIG, "included_prs": [row["pr"] for row in rows], "excluded_prs": excluded,
        "overlapping_prs": intervals, "metrics": summary, "by_pr": rows,
        "canonical_runs_outside_included_prs": [
            {"run": run["id"], "head_branch": run["head_branch"], "created_at": run["created_at"]}
            for run in runs if run["id"] not in considered
        ],
    }
    (REPLAY / "production-metrics.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(f"Measured {count} cohort PRs, {len(considered)} run IDs, "
          f"{sum(len(row['attempts']) for row in rows)} attempts.")


if __name__ == "__main__":
    main()
